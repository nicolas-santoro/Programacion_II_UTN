package actividad1;



import java.time.LocalDate;


public class Persona {
    private String nombre;
    private String apellido;
    private final int anioDeNacimiento;

    public Persona(String nombre, String apellido, int anioDeNacimiento) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.anioDeNacimiento = anioDeNacimiento;
    }
    
    
    public String getNombreCompleto() {
        return this.nombre + " " + this.apellido + " ";
    }

    public int getEdadActual() {
        int anioActual = LocalDate.now().getYear();
        
        
        return anioActual - this.anioDeNacimiento;
    }

    public boolean esMayor() {
        return this.anioDeNacimiento >= 18;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }


    public void setNombreApellido(String nombre, String apellido) {
        setNombre(nombre);
        setApellido(apellido);
    }

    public void mostrarDatos() {
        StringBuilder sb = new StringBuilder();
        
        sb.append("Nombre: ").append(this.nombre).append(". ");
        sb.append("Apellido: ").append(this.apellido).append(". ");
        int edad = getEdadActual();
        sb.append("Edad: ").append(edad).append(" anios.");
        
        System.out.println(sb.toString());
    }
}