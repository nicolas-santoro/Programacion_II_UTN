package actividad1;



public class Principal {
    public static void main(String[] args) {
        Persona nico = new Persona("Nicolas", "Santoro", 2006);
        
        String nombreCompleto = nico.getNombreCompleto();
        System.out.println(nombreCompleto);
        boolean mayoria = nico.esMayor();
        System.out.println(mayoria);
        int edad = nico.getEdadActual();
        System.out.println("La edad actual de " + nombreCompleto + "es de " + edad + " anios.");
        nico.mostrarDatos();
    }
}