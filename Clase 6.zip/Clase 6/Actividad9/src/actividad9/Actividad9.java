package actividad9;



import java.time.LocalDate;


public class Actividad9 {
    public static void main(String[] args) {
        Impresora impresora = new Impresora();
        impresora.encender();
        
        Documento documento = new Documento(LocalDate.now(), "Genshin Impact", "ESTE JUEGO ES UN MALDITO BODRIO, AYUDA");
        
        impresora.recargarBandeja(20); // Añade 20 hojas
        impresora.imprimir(documento);  // Imprime el documento
        
        // Verificar estado de la impresora después de imprimir
        System.out.println("Nivel de tinta restante: " + impresora.getNivelTinta());
        System.out.println("Cantidad de hojas restantes: " + impresora.getCantidadHojas());
    }
}