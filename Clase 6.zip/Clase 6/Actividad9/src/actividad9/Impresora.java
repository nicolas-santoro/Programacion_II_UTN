package actividad9;



public class Impresora {
    private boolean encendida;
    private int cantidadHojas;
    private int nivelTinta;

    private static final int MAX_HOJAS = 35;
    private static final int CONSUMO_TINTA_POR_CARACTER = 50;
    private static final int CONSUMO_HOJAS_POR_CARACTER = 20;
    private static final int NIVEL_TINTA_INICIAL = 100;

    public Impresora() {
        this.encendida = false;
        this.cantidadHojas = 0;
        this.nivelTinta = NIVEL_TINTA_INICIAL;
    }

    public int nivelSegunCantCaracteres(int cantidadCaracteres) {
        // Calcula la cantidad de tinta necesaria para imprimir la cantidad de caracteres
        return (cantidadCaracteres + CONSUMO_TINTA_POR_CARACTER - 1) / CONSUMO_TINTA_POR_CARACTER;
    }

    public void recargarBandeja(int cantidad) {
        if (cantidad > 0) {
            this.cantidadHojas = Math.min(MAX_HOJAS, this.cantidadHojas + cantidad);
        }
    }

    public void imprimir(Documento documento) {
        if (!encendida) {
            System.out.println("La impresora está apagada.");
            return;
        }

        int cantidadCaracteres = documento.getCuerpo().length();
        int tintaRequerida = nivelSegunCantCaracteres(cantidadCaracteres);
        int hojasRequeridas = (cantidadCaracteres + CONSUMO_HOJAS_POR_CARACTER - 1) / CONSUMO_HOJAS_POR_CARACTER;

        if (tintaRequerida > nivelTinta) {
            System.out.println("No hay suficiente tinta para imprimir el documento.");
            return;
        }

        if (hojasRequeridas > cantidadHojas) {
            System.out.println("No hay suficientes hojas en la bandeja para imprimir el documento.");
            return;
        }

        // Imprime el documento
        System.out.println("Fecha: " + documento.getFecha() + " " + documento.getTitulo());
        System.out.println(documento.getCuerpo());

        // Actualiza el nivel de tinta y la cantidad de hojas
        nivelTinta -= tintaRequerida;
        cantidadHojas -= hojasRequeridas;
    }

    public void encender() {
        this.encendida = true;
    }

    public void apagar() {
        this.encendida = false;
    }

    public boolean isEncendida() {
        return encendida;
    }

    public int getCantidadHojas() {
        return cantidadHojas;
    }

    public int getNivelTinta() {
        return nivelTinta;
    }
}