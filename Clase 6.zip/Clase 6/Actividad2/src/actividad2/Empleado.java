package actividad2;



public class Empleado {
    private int dni;
    private String nombre;
    private String apellido;
    private double salarioBase;
    private EstadoCivil estadoCivil;
    private int cantidadDeHijos;

    public Empleado(int dni, String nombre, String apellido, double salarioBase, EstadoCivil estadoCivil) {
        this.dni = dni;
        this.nombre = nombre;
        this.apellido = apellido;
        this.salarioBase = salarioBase;
        this.estadoCivil = estadoCivil;
    }
    
    public double obtenerSalarioFinal() {
        // 1. Calcular el extra por hijos (máximo 15%)
        double porcentajeExtraHijos = Math.min(cantidadDeHijos * 0.04, 0.15);
        
        // 2. Calcular el salario con el extra por hijos
        double salarioConExtra = salarioBase * (1 + porcentajeExtraHijos);
        
        // 3. Descontar el 4% si el empleado es soltero
        if (estadoCivil == EstadoCivil.SOLTERO) {
            salarioConExtra *= 0.96;  // Aplicamos un descuento del 4%
        }
        
        // 4. Retornar el salario final
        return salarioConExtra;
    }
}