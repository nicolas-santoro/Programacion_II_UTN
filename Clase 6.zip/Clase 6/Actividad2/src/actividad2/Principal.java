package actividad2;



public class Principal {
    public static void main(String[] args) {
        Empleado empleado1 = new Empleado(47297658, "Nicolas", "Santoro", (double) 25252525, EstadoCivil.SOLTERO);
        
        double salario = empleado1.obtenerSalarioFinal();
        System.out.println("Su salario es de: $" + salario);
    }
}