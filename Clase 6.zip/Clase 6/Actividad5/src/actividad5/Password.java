package actividad5;



import java.security.SecureRandom;


public class Password {
    private String contra;

    public boolean esFuerte() {
        int longitud = this.contra.length();
        
        return longitud >= 8;
    }

    public void nuevoValor(String contraNueva) {
        int longitud = contraNueva.length();
        
        if (longitud >= 6){
            this.contra = contraNueva;
            
            System.out.println("La contrasenia fue cambiada exitosamente...");
        }
        
        else {
            System.out.println("Error, la contrasenia debe tener como minimo 6 caracteres. Nada cambio...");
        }
    }
    
    private static final String CARACTERES_VALIDOS = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
    
    public static String generarAleatorio(int longitud) {
        // Verificar que la longitud sea al menos 6
        if (longitud < 6) {
            return null;
        }
        // Crear un generador de números aleatorios
        SecureRandom random = new SecureRandom();
        
        // Crear un StringBuilder para construir la contraseña
        StringBuilder contraseña = new StringBuilder(longitud);

        // Construir la contraseña
        for (int i = 0; i < longitud; i++) {
            // Elegir un carácter aleatorio del conjunto de caracteres válidos
            int indice = random.nextInt(CARACTERES_VALIDOS.length());
            char caracterAleatorio = CARACTERES_VALIDOS.charAt(indice);
            contraseña.append(caracterAleatorio);
        }

        return contraseña.toString();
    }

    public Password(String contra) {
        this.contra = contra;
    }

    public Password() {
        this.contra = generarAleatorio(8);
    }
}