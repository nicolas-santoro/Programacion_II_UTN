package actividad5;



public class Principal {
    public static void main(String[] args) {
        Password contra1 = new Password();
        
        boolean fortaleza = contra1.esFuerte();
        System.out.println(fortaleza);
    }
}