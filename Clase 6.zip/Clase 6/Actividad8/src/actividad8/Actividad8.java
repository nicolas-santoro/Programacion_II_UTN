package actividad8;



import java.time.LocalDate;


public class Actividad8 {
    public static void main(String[] args) {
         Domicilio domicilioInicial = new Domicilio("Av. Siempreviva", 742, "Campo primaveral");

        // Crear objetos Persona
        Persona juan = new Persona("Juan", "Perez", LocalDate.of(1986, 4, 6), domicilioInicial);
        Persona maria = new Persona("Maria", "Fernandez", LocalDate.of(1990, 1, 9), domicilioInicial);

        // Crear objetos CuentaBancaria
        CuentaBancaria cuentaJuan = new CuentaBancaria(252423213, Tipo.CAJA_DE_AHORRO, 50000, "Juan", LocalDate.of(2001, 1, 9));
        CuentaBancaria cuentaMaria = new CuentaBancaria(131323213, Tipo.CUENTA_CORRIENTE, 50000, "Maria", LocalDate.of(2001, 4, 6));

        // Mostrar datos iniciales
        juan.mostrarDatos();
        maria.mostrarDatos();

        // Nuevo domicilio
        Domicilio nuevoDomicilio = new Domicilio("Calle Nueva", 123, "Nuevo Barrio");

        // Actualizar domicilio de ambas personas
        juan.setDomicilio(nuevoDomicilio);
        maria.setDomicilio(nuevoDomicilio);

        // Mostrar datos después del cambio de domicilio
        juan.mostrarDatos();
        maria.mostrarDatos();
    }
}