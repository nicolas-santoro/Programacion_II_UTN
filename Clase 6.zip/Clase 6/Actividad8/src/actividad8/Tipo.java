package actividad8;



public enum Tipo {
    CAJA_DE_AHORRO,
    CUENTA_CORRIENTE;
}