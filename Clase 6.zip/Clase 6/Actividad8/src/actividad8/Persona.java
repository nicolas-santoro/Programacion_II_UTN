package actividad8;



import java.time.LocalDate;
import java.time.Period;


public class Persona {
    private String nombre;
    private String apellido;
    private final LocalDate fechaDeNacimiento;
    private Domicilio domicilio;

    public Persona(String nombre, String apellido, LocalDate anioDeNacimiento, Domicilio domicilio) {
        setNombreApellido(nombre, apellido);
        this.fechaDeNacimiento = anioDeNacimiento;
        setDomicilio(domicilio);
    }
    
    
    public String getNombreCompleto() {
        return this.nombre + " " + this.apellido + " ";
    }

    public int getEdadActual() {
        // Obtiene la fecha actual
        LocalDate hoy = LocalDate.now();
        
        // Calcula el periodo entre la fecha de nacimiento y la fecha actual
        Period periodo = Period.between(this.fechaDeNacimiento, hoy);
        
        // Devuelve la edad en años
        return periodo.getYears();
    }

    public boolean esMayor() {
        int edad = getEdadActual();
        
        return edad >= 18;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public void setNombreApellido(String nombre, String apellido) {
        setNombre(nombre);
        setApellido(apellido);
    }

    public void setDomicilio(Domicilio domicilio) {
        this.domicilio = domicilio;
    }
    
    public void mostrarDatos() {
        StringBuilder sb = new StringBuilder();
        
        sb.append("Nombre: ").append(this.nombre).append(". ");
        sb.append("Apellido: ").append(this.apellido).append(". ");
        int edad = getEdadActual();
        sb.append("Edad: ").append(edad).append(" anios. ");
        
        String calle = domicilio.getCalle();
        int altura = domicilio.getAltura();
        String barrio = domicilio.getBarrio();
        sb.append("Domicilio: ").append(calle).append(", ").append(altura).append(", ").append(barrio);
        
        System.out.println(sb.toString());
    }
}