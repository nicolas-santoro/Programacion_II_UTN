package actividad4;



public class Principal {
    public static void main(String[] args) {
        CuentaBancaria cuenta1 = new CuentaBancaria(252423213, Tipo.CAJA_DE_AHORRO, 40000);
        CuentaBancaria cuenta2 = new CuentaBancaria(131323213, Tipo.CUENTA_CORRIENTE, 50000);
        
        cuenta1.obtenerSaldo();
        cuenta1.depositarDinero(6000);
        cuenta1.obtenerSaldo();
        cuenta1.extraerDinero(11000);
        cuenta1.obtenerSaldo();
        System.out.println("");
        cuenta2.obtenerSaldo();
        cuenta2.extraerDinero(51000);
        cuenta2.obtenerSaldo();
    }
}