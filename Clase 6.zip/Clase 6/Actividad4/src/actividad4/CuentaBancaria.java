package actividad4;



public class CuentaBancaria {
    private int cbu;
    private final Tipo tipo;
    private double saldo = 0;

    public CuentaBancaria(int cbu, Tipo tipo, double saldo) {
        this.cbu = cbu;
        this.tipo = tipo;
        this.saldo = saldo;
    }
    

    public void obtenerSaldo() {
        System.out.println("Su saldo es de: $" + this.saldo);
    }

    public void depositarDinero(int deposito) {
        double aDepositar = this.saldo + deposito;
        
        this.saldo = aDepositar;
    }

    public void extraerDinero(int extraccion) {
        if (this.tipo == Tipo.CUENTA_CORRIENTE){
            double aExtraer = this.saldo - extraccion;
            this.saldo = aExtraer;
        }
        
        else{
            double aExtraer = this.saldo - extraccion;
            this.saldo = aExtraer;
            
            if (aExtraer < 0){
                this.saldo = 0;
            }
        }
    }

    public void obtenerUltimos3Cbu() {
         // Convierte el CBU a una cadena de texto con relleno de ceros a la izquierda
        String cbuStr = String.format("%022d", cbu);
        // Devuelve los últimos 3 dígitos
        System.out.println("Ultimos 3 digitos de su CBU: " + cbuStr);
    }
}