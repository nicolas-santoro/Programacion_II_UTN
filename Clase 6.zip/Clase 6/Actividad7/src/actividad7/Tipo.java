package actividad7;



public enum Tipo {
    CAJA_DE_AHORRO,
    CUENTA_CORRIENTE;
}