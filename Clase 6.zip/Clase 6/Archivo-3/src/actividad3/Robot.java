package actividad3;



public class Robot {
    private static final String nombre = "Robotnik";

    public static void saludar() {
        System.out.println("Hola, mi nombre es " + nombre + ". En que puedo ayudarte?");
    }

    public static void saludar(Persona usuario) {
        System.out.println("Hola " + usuario.getDatos() + ", mi nombre es " + nombre + ". En que puedo ayudarte?");
    }
}