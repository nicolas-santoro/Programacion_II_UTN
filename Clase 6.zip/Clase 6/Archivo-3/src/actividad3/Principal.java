package actividad3;



public class Principal {
    public static void main(String[] args) {
        Persona usuario1 = new Persona("Nicolas", "Santoro");
        Persona usuario2 = new Persona("Sonic", "The Hedgehog");
        
        Robot.saludar();
        Robot.saludar(usuario1);
        Robot.saludar(usuario2);
    }
}