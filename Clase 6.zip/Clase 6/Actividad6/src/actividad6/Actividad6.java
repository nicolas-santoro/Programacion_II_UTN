package actividad6;



import java.time.LocalDate;


public class Actividad6 {
    public static void main(String[] args) {
        Domicilio domicilio = new Domicilio("Quintana", 376, "Lanus");
        Persona nico = new Persona("Nicolas", "Santoro", LocalDate.of(2006, 5, 15), domicilio);
        
        String nombreCompleto = nico.getNombreCompleto();
        System.out.println(nombreCompleto);
        boolean mayoria = nico.esMayor();
        System.out.println(mayoria);
        int edad = nico.getEdadActual();
        System.out.println("La edad actual de " + nombreCompleto + "es de " + edad + " anios.");
        nico.mostrarDatos();
    }
}