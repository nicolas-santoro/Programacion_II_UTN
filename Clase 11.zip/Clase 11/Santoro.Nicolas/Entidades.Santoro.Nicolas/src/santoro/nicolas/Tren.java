package santoro.nicolas;



import java.util.ArrayList;


public abstract class Tren {
    protected int cantidadMaximaPasajeros;
    protected String destino;
    protected boolean motorEncendido;

    public Tren(int cantidadMaximaPasajeros, String destino) {
        this.cantidadMaximaPasajeros = cantidadMaximaPasajeros;
        this.destino = destino;
    }

    public int getCantidadMaximaPasajeros() {
        return cantidadMaximaPasajeros;
    }

    public boolean isMotorEncendido() {
        return motorEncendido;
    }

    public String getDestino() {
        return destino;
    }

    public void setMotorEncendido(boolean motorEncendido) {
        this.motorEncendido = motorEncendido;
    }

    public abstract ArrayList<Pasajero> getPasajeros();

    public static boolean sonIguales(Pasajero pasajero, Tren tren) {
        // Llama al método getPasajeros() de manera polimórfica
        return tren.getPasajeros().contains(pasajero);
    }

    public void agregar(Pasajero pasajero) {
         // Obtener la lista de pasajeros de la clase hija
        ArrayList<Pasajero> pasajeros = getPasajeros();
        
        for (Pasajero p : pasajeros) {
            if (Pasajero.sonIguales(p, pasajero)) {
                System.out.println("El pasajero ya existe en el tren.");
                return; // No agregar el pasajero si ya existe
            }
        }
        
        if (pasajeros.size() >= this.cantidadMaximaPasajeros) {
            System.out.println("Se ha superado la cantidad maxima de pasajeros.");
            System.out.println("");
        }
        
        
        else{
            pasajeros.add(pasajero);
        }
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        
        sb.append("Capacidad Maxima: ").append(this.cantidadMaximaPasajeros).append("\n");
        sb.append("Destino: ").append(this.destino).append("\n");
        sb.append("El motor esta encendido?: ").append(this.motorEncendido).append("\n");
        
        
        return sb.toString();
    }
}