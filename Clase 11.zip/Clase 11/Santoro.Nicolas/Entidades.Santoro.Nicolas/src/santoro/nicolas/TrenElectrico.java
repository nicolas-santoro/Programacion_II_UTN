package santoro.nicolas;



import java.util.ArrayList;


public class TrenElectrico extends Tren {
    protected ArrayList<Pasajero> pasajeros;

    public TrenElectrico(int cantidadMaximaPasajeros, String destino) {
        super(cantidadMaximaPasajeros, destino);
        
        this.pasajeros = new ArrayList<>();
    }

    @Override
    public ArrayList<Pasajero> getPasajeros() {
        return this.pasajeros;
    }
    
     @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        
        sb.append(super.toString()).append("\n");
        sb.append("Pasajeros: ").append("\n");
    
        for (Pasajero pasajero : this.pasajeros){
            sb.append(pasajero.toString()).append("\n");
        }
        
        
        return sb.toString();
    }
}