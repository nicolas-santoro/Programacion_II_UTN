package santoro.nicolas;



import java.util.ArrayList;


public class TrenBala extends Tren {

    protected int cantidadElectroimanes;
    protected ArrayList<Pasajero> pasajeros;

    public TrenBala(int cantidadMaximaPasajeros, String destino, int electroImanes) {
        super(cantidadMaximaPasajeros, destino);
        this.cantidadElectroimanes = electroImanes;
        
        this.pasajeros = new ArrayList<>();
    }
    
    @Override
    public ArrayList<Pasajero> getPasajeros() {
        return this.pasajeros;
    }
    
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        
        sb.append(super.toString()).append("\n");
        sb.append("Cantidad de Electroimanes: ").append(this.cantidadElectroimanes).append("\n");
        sb.append("Pasajeros: ").append("\n");
    
        for (Pasajero pasajero : this.pasajeros){
            sb.append(pasajero.toString()).append("\n");
        }
        
        
        return sb.toString();
    }
}