package santoro.nicolas;



import java.util.Objects;


public class Pasajero {
    private String apellido;
    private String nombre;
    private Rangos rango;

    public Pasajero() {
        this.apellido = "SIN APELLIDO";
        this.nombre = "SIN NOMBRE";
        this.rango = Rangos.CLIENTE;
    }

    public Pasajero(String apellido) {
        this();
        this.apellido = apellido;
    }

    public Pasajero(String apellido, String nombre) {
        this(apellido);
        this.nombre = nombre;
    }

    public Pasajero(String apellido, String nombre, Rangos rango) {
        this(apellido, nombre);
        this.rango = rango;
    }

    public String getApellido() {
        return apellido;
    }

    public String getNombre() {
        return nombre;
    }

    public Rangos getRango() {
        return rango;
    }

    public static boolean sonIguales(Pasajero pasajero1, Pasajero pasajero2) {
        return pasajero1.nombre.equals(pasajero2.nombre) &&
                pasajero1.apellido.equals(pasajero2.apellido) && 
                pasajero1.rango.equals(pasajero2.rango);
    }
    
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        
        sb.append("Nombre: ").append(this.nombre).append("\n");
        sb.append("Apellido: ").append(this.apellido).append("\n");
        sb.append("Rango: ").append(this.rango).append("\n");
        
        return sb.toString();
    }
    
    @Override
    public boolean equals(Object obj) {
        // Verifica si la comparación es con el mismo objeto
        if (this == obj) {
            return true;
        }

        // Verifica si el objeto es de la misma clase
        if (obj instanceof Pasajero otroPasajero) {
            // Compara los atributos nombre y apellido de manera segura
            return Objects.equals(this.nombre, otroPasajero.nombre) && 
                   Objects.equals(this.apellido, otroPasajero.apellido);
        }

        
        return false; // Son diferentes tipos de objeto
    }
    
    @Override
    public int hashCode() {
        return Objects.hash(this.apellido, this.nombre, this.rango);
    }
}