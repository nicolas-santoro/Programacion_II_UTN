package santoro.nicolas;



public enum Rangos {
    AZAFATA,
    COCINERO,
    MAQUINISTA,
    CLIENTE;
}