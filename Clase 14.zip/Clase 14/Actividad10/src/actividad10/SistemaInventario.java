package actividad10;



import java.util.ArrayList;


public class SistemaInventario {
    private ArrayList<ItemInventario> inventario;

    public SistemaInventario() {
        this.inventario = new ArrayList<>();
    }

    public void agregarItem(ItemInventario item) {
        this.inventario.add(item);
        
        System.out.println("Item agregado al inventario...");
    }

    public void agregarStock(ItemInventario item, int cantidad) {
        item.agregarStock(cantidad);
    }

    public void quitarStock(ItemInventario item, int cantidad) {
        item.quitarStock(cantidad);
    }
}