package actividad10;



public interface ItemInventario {
    void agregarStock(int cantidad);  // Método para agregar stock
    void quitarStock(int cantidad);   // Método para quitar stock
}