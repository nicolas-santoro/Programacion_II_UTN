package actividad10;



public class Servicio implements ItemInventario{
    private String descripcion;
    private int cantidadDisponible;

    public Servicio(String descripcion, int disponibilidadInicial) {
        this.descripcion = descripcion;
        this.cantidadDisponible = disponibilidadInicial;
    }

    @Override
    public void agregarStock(int cantidad) {
        this.cantidadDisponible += cantidad;
        
        System.out.println("Se han agregado " + cantidad + " unidades de disponibilidad para el servicio: " + this.descripcion + ". Disponibilidad actual: " + this.cantidadDisponible);
    }

    @Override
    public void quitarStock(int cantidad) {
        if (cantidad > 0 && cantidad <= this.cantidadDisponible) {
            this.cantidadDisponible -= cantidad;
            System.out.println("Se han quitado " + cantidad + " unidades de disponibilidad para el servicio: " + this.descripcion + ". Disponibilidad actual: " + this.cantidadDisponible);
        } 
        
        else {
            System.out.println("Cantidad invalida o no hay suficiente disponibilidad del servicio: " + this.descripcion);
        }
    }

    public int getCantidadDisponible() {
        return this.cantidadDisponible;
    }
}