package actividad10;



public class Producto implements ItemInventario{
    private String nombre;
    private int stock;

    public Producto(String nombre, int stockInicial) {
        this.nombre = nombre;
        this.stock = stockInicial;
    }

    @Override
    public void agregarStock(int cantidad) {
        if (cantidad > 0) {
            this.stock += cantidad;
            
            System.out.println("Se han agregado " + cantidad + " unidades de " + this.nombre + ". Stock actual: " + this.stock);
        } 
        
        else {
            System.out.println("La cantidad a agregar debe ser positiva.");
        }
    }

    @Override
    public void quitarStock(int cantidad) {
        if (cantidad > 0 && cantidad <= this.stock) {
            this.stock -= cantidad;
            
            System.out.println("Se han quitado " + cantidad + " unidades de " + this.nombre + ". Stock actual: " + this.stock);
        } 
        
        else {
            System.out.println("Cantidad invalida o no hay suficiente stock de " + this.nombre);
        }
    }

    public int getStock() {
        return this.stock;
    }
}