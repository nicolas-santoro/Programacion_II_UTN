package actividad10;



public class Actividad10 {
    public static void main(String[] args) {
        // Crear instancias de Producto y Servicio
        Producto producto1 = new Producto("Laptop", 10);
        Servicio servicio1 = new Servicio("Mantenimiento de PC", 5);

        // Crear el sistema de inventario
        SistemaInventario sistema = new SistemaInventario();

        // Agregar ítems al inventario
        sistema.agregarItem(producto1);
        sistema.agregarItem(servicio1);

        // Administrar el stock de productos y servicios
        sistema.agregarStock(producto1, 5);  // Agregar stock a Producto
        sistema.quitarStock(producto1, 3);  // Quitar stock a Producto

        sistema.agregarStock(servicio1, 2);  // Agregar disponibilidad a Servicio
        sistema.quitarStock(servicio1, 1);  // Quitar disponibilidad a Servicio
    }
}