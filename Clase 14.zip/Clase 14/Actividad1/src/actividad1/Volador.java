package actividad1;



public interface Volador {
    void despegar();    // Método para despegar
    void aterrizar();   // Método para aterrizar
}