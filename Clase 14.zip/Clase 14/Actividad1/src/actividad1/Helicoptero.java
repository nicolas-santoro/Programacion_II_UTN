package actividad1;



public class Helicoptero implements Volador{
    @Override
    public void despegar() {
        System.out.println("El helicoptero esta despegando...");
    }

    @Override
    public void aterrizar() {
        System.out.println("El helicoptero ha aterrizado...");
    }
}