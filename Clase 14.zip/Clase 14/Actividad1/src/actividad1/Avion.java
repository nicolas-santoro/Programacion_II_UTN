package actividad1;



public class Avion implements Volador{
    @Override
    public void despegar() {
        System.out.println("El avion esta despegando...");
    }

    @Override
    public void aterrizar() {
        System.out.println("El avion ha aterrizado...");
    }
}