package actividad1;



public class Actividad1 {
    public static void main(String[] args) {
        // Crear instancias de Avion y Helicoptero
        Avion avion = new Avion();
        Helicoptero helicoptero = new Helicoptero();

        // Simular despegue y aterrizaje del avión
        System.out.println("Simulando el avion:");
        avion.despegar();
        avion.aterrizar();

        // Simular despegue y aterrizaje del helicóptero
        System.out.println("\nSimulando el helicoptero:");
        helicoptero.despegar();
        helicoptero.aterrizar();
    }
}