package actividad8;



public class CamionAutonomo implements Conducible{
    @Override
    public void acelerar() {
        System.out.println("El camion autonomo esta acelerando...");
    }

    @Override
    public void frenar() {
        System.out.println("El camion autonomo esta frenando...");
    }

    @Override
    public void girar(String direccion) {
        System.out.println("El camion autonomo esta girando hacia la " + direccion);
    }
}