package actividad8;



public interface Conducible {
     void acelerar();  // Método para acelerar
    void frenar();    // Método para frenar
    void girar(String direccion);  // Método para girar (izquierda o derecha)
}