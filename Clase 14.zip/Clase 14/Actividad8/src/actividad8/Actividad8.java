package actividad8;



public class Actividad8 {
    public static void main(String[] args) {
        // Crear una instancia de CocheAutonomo y procesarla mediante el simulador
        CocheAutonomo coche = new CocheAutonomo();
        Simulador simulador = new Simulador();
        simulador.recorrerRuta(coche);

        // Crear una instancia de CamionAutonomo y procesarla mediante el simulador
        CamionAutonomo camion = new CamionAutonomo();
        simulador.recorrerRuta(camion);
    }
}