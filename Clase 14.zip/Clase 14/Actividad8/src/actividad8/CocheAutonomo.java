package actividad8;



public class CocheAutonomo implements Conducible{
    @Override
    public void acelerar() {
        System.out.println("El coche autonomo esta acelerando...");
    }

    @Override
    public void frenar() {
        System.out.println("El coche autonomo esta frenando...");
    }

    @Override
    public void girar(String direccion) {
        System.out.println("El coche autonomo esta girando hacia la " + direccion);
    }
}