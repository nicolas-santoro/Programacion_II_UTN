package actividad8;




public class Simulador {
    public void recorrerRuta(Conducible vehiculo) {
        System.out.println("Iniciando simulacion de recorrido...");
        vehiculo.acelerar();
        vehiculo.girar("izquierda");
        vehiculo.frenar();
        vehiculo.girar("derecha");
        vehiculo.acelerar();
        vehiculo.frenar();
        System.out.println("Recorrido finalizado.\n");
    }
}