package actividad2;



import java.util.ArrayList;


public class Actividad2 {
    public static void main(String[] args) {
         // Crear una lista de elementos imprimibles
        ArrayList<Imprimible> imprimibles = new ArrayList<>();

        // Agregar instancias de Documento y Foto a la lista
        imprimibles.add(new Documento("Contrato Legal"));
        imprimibles.add(new Foto("vacaciones.jpg"));
        imprimibles.add(new Documento("Informe de Ventas"));
        imprimibles.add(new Foto("cumpleanios.png"));

        // Imprimir todos los elementos de la lista
        for (Imprimible imprimible : imprimibles) {
            imprimible.imprimir();
        }
    }
}