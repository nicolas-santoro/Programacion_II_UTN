package actividad2;



public class Documento implements Imprimible {
    private String titulo;

    public Documento(String titulo) {
        this.titulo = titulo;
    }

    @Override
    public void imprimir() {
        System.out.println("Imprimiendo documento: " + this.titulo);
    }
}