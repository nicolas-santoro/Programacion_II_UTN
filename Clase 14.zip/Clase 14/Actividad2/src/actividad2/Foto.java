package actividad2;



public class Foto implements Imprimible{
    private String nombreArchivo;

    public Foto(String nombreArchivo) {
        this.nombreArchivo = nombreArchivo;
    }

    @Override
    public void imprimir() {
        System.out.println("Imprimiendo foto: " + this.nombreArchivo);
    }
}
