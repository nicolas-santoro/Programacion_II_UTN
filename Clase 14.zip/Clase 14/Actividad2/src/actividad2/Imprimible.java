package actividad2;


public interface Imprimible {
    void imprimir();  // Método para imprimir
}