package actividad3;



public class Empleado implements Pagable {
    private String nombre;
    private double salario;

    public Empleado(String nombre, double salario) {
        this.nombre = nombre;
        this.salario = salario;
    }

    @Override
    public void pagar() {
        System.out.println("Pagando salario de $" + this.salario + " a " + this.nombre);
    }
}