package actividad3;



public class Freelancer implements Pagable {
    private String nombre;
    private double tarifa;
    private int horasTrabajadas;

    public Freelancer(String nombre, double tarifa, int horasTrabajadas) {
        this.nombre = nombre;
        this.tarifa = tarifa;
        this.horasTrabajadas = horasTrabajadas;
    }

    @Override
    public void pagar() {
        double pagoTotal = this.tarifa * this.horasTrabajadas;
        System.out.println("Pagando $" + pagoTotal + " al freelancer " + this.nombre + " por " + this.horasTrabajadas + " horas trabajadas.");
    }
}