package actividad3;



import java.util.ArrayList;


public class Actividad3 {
    public static void main(String[] args) {
        // Crear una lista de objetos pagables
        ArrayList<Pagable> pagables = new ArrayList<>();

        // Agregar instancias de Empleado y Freelancer a la lista
        pagables.add(new Empleado("Carlos", 3000));
        pagables.add(new Freelancer("Ana", 50, 40)); // Ana trabaja 40 horas a 50 por hora
        pagables.add(new Empleado("Luis", 3500));
        pagables.add(new Freelancer("Maria", 60, 30)); // María trabaja 30 horas a 60 por hora

        // Procesar el pago de todos los objetos pagables
        for (Pagable pagable : pagables) {
            pagable.pagar();
        }
    }
}