package actividad3;



public interface Pagable {
    void pagar();  // Método para procesar el pago
}