package actividad9;



public interface Reservable {
    void reservar();         // Método para realizar una reserva
    void cancelarReserva();  // Método para cancelar una reserva
}