package actividad9;



public class Vuelo implements Reservable{
    private String numeroVuelo;
    private boolean reservado;

    public Vuelo(String numeroVuelo) {
        this.numeroVuelo = numeroVuelo;
        this.reservado = false;  // Por defecto, no está reservado
    }

    @Override
    public void reservar() {
        if (!this.reservado) {
            this.reservado = true;
            
            System.out.println("Reserva realizada para el vuelo " + this.numeroVuelo);
        } 
        
        else {
            System.out.println("El vuelo " + this.numeroVuelo + " ya esta reservado.");
        }
    }

    @Override
    public void cancelarReserva() {
        if (this.reservado) {
            this.reservado = false;
            
            System.out.println("Reserva cancelada para el vuelo " + this.numeroVuelo);
        } 
        
        else {
            System.out.println("No hay ninguna reserva para el vuelo " + this.numeroVuelo);
        }
    }
}