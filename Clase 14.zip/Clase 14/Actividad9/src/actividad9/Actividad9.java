package actividad9;



public class Actividad9 {
    public static void main(String[] args) {
        // Crear instancias de Hotel y Vuelo
        Hotel hotel = new Hotel("Hotel Paraiso");
        Vuelo vuelo = new Vuelo("AR1234");

        // Crear el sistema de reservas
        SistemaReservas sistema = new SistemaReservas();

        // Gestionar las reservas
        sistema.gestionarReserva(hotel);
        sistema.gestionarReserva(vuelo);

        // Cancelar las reservas
        sistema.cancelarReservacion(hotel);
        sistema.cancelarReservacion(vuelo);
    }
}