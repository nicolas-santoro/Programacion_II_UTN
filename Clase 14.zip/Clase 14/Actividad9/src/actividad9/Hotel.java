package actividad9;



public class Hotel implements Reservable{
    private String nombre;
    private boolean reservado;

    public Hotel(String nombre) {
        this.nombre = nombre;
        this.reservado = false;  // Por defecto, no está reservado
    }

    @Override
    public void reservar() {
        if (!this.reservado) {
            this.reservado = true;
            
            System.out.println("Reserva realizada en el hotel " + this.nombre);
        } 
        
        else {
            System.out.println("El hotel " + this.nombre + " ya esta reservado.");
        }
    }

    @Override
    public void cancelarReserva() {
        if (this.reservado) {
            this.reservado = false;
            
            System.out.println("Reserva cancelada en el hotel " + this.nombre);
        } 
        
        else {
            System.out.println("No hay ninguna reserva en el hotel " + this.nombre);
        }
    }
}