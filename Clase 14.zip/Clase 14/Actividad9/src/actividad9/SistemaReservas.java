package actividad9;



import java.util.ArrayList;


public class SistemaReservas {
    private ArrayList<Reservable> reservas;

    public SistemaReservas() {
        this.reservas = new ArrayList<>();
    }

    // Método para añadir una nueva reserva
    public void gestionarReserva(Reservable servicio) {
        this.reservas.add(servicio);
        
        servicio.reservar();
    }

    // Método para cancelar una reserva existente
    public void cancelarReservacion(Reservable servicio) {
        if (this.reservas.contains(servicio)) {
            servicio.cancelarReserva();
            
            this.reservas.remove(servicio);
        } 
    }
}