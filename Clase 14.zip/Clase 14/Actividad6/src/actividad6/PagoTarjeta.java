package actividad6;



public class PagoTarjeta implements Transaccion{
    private String numeroTarjeta;
    private double monto;

    public PagoTarjeta(String numeroTarjeta, double monto) {
        this.numeroTarjeta = numeroTarjeta;
        this.monto = monto;
    }

    @Override
    public void procesar() {
        System.out.println("Procesando pago de $" + this.monto + " mediante la tarjeta: " + this.numeroTarjeta + "...");
    }
}