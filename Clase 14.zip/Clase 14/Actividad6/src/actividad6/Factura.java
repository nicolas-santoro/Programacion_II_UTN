package actividad6;



public class Factura{
    private Transaccion transaccion;
    private double monto;

    public Factura(Transaccion transaccion, double monto) {
        this.transaccion = transaccion;
        this.monto = monto;
    }

    public void procesarPago() {
        System.out.println("Generando factura por $" + this.monto);
        
        this.transaccion.procesar();  // Procesa el pago según el tipo de transacción
    }
}