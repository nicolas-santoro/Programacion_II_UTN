package actividad6;



public class Actividad6 {
    public static void main(String[] args) {
         // Crear una instancia de PagoTarjeta y procesarla mediante Factura
        PagoTarjeta pagoTarjeta = new PagoTarjeta("1234-5678-9876-5432", 150.75);
        Factura facturaTarjeta = new Factura(pagoTarjeta, 150.75);
        facturaTarjeta.procesarPago();

        // Crear una instancia de PagoEfectivo y procesarla mediante Factura
        PagoEfectivo pagoEfectivo = new PagoEfectivo(200.50);
        Factura facturaEfectivo = new Factura(pagoEfectivo, 200.50);
        facturaEfectivo.procesarPago();
    }  
}