package actividad6;




public interface Transaccion {
    void procesar();  // Método para procesar el pago
}