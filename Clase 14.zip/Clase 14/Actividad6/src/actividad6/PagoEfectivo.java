package actividad6;



public class PagoEfectivo implements Transaccion{
    private double monto;

    public PagoEfectivo(double monto) {
        this.monto = monto;
    }

    @Override
    public void procesar() {
        System.out.println("Procesando pago de $" + this.monto + " en efectivo...");
    }
}