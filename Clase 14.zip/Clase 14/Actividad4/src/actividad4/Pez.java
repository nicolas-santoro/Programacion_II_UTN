package actividad4;



public class Pez implements Nadador{
    private String especie;

    public Pez(String especie) {
        this.especie = especie;
    }

    @Override
    public void nadar() {
        System.out.println("El pez " + this.especie + " esta nadando en el oceano.");
    }
}