package actividad4;



public interface Nadador {
    void nadar();  // Método para nadar
}