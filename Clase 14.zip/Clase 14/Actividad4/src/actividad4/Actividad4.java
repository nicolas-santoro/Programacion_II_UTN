package actividad4;



import java.util.ArrayList;


public class Actividad4 {
    public static void main(String[] args) {
        // Crear una lista de nadadores
        ArrayList<Nadador> nadadores = new ArrayList<>();

        // Agregar instancias de Persona y Pez a la lista
        nadadores.add(new Persona("Carlos"));
        nadadores.add(new Pez("Dorado"));
        nadadores.add(new Persona("Ana"));
        nadadores.add(new Pez("Tiburon"));

        // Simular cómo nadan
        for (Nadador nadador : nadadores) {
            nadador.nadar();
        }
    }
}