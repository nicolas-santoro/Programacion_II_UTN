package actividad4;



public class Persona implements Nadador {
    private String nombre;

    public Persona(String nombre) {
        this.nombre = nombre;
    }

    @Override
    public void nadar() {
        System.out.println(this.nombre + " esta nadando en la piscina.");
    }
}