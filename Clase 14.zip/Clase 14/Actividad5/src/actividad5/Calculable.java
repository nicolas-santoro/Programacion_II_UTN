package actividad5;



public interface Calculable {
    double calcularArea();  // Método para calcular el área
}