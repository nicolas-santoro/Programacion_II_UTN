package actividad5;



import java.util.ArrayList;


public class Actividad5 {
    public static void main(String[] args) {
        // Crear una lista de objetos Calculable
        ArrayList<Calculable> formas = new ArrayList<>();

        // Agregar instancias de Rectangulo y Circulo a la lista
        formas.add(new Rectangulo(5, 10));  // Rectángulo con ancho 5 y alto 10
        formas.add(new Circulo(7));         // Círculo con radio 7
        formas.add(new Rectangulo(3, 4));   // Otro rectángulo con diferentes medidas
        formas.add(new Circulo(2.5));       // Círculo con radio 2.5

        // Calcular y mostrar el área de cada forma
        for (Calculable forma : formas) {
            System.out.println("El area es: " + forma.calcularArea());
        }
    }
}