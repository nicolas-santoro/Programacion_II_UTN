package actividad5;



public class Rectangulo implements Calculable{
    private double ancho;
    private double alto;

    public Rectangulo(double ancho, double alto) {
        this.ancho = ancho;
        this.alto = alto;
    }

    @Override
    public double calcularArea() {
        return this.ancho * this.alto;  // Fórmula del área del rectángulo: base * altura
    }
}