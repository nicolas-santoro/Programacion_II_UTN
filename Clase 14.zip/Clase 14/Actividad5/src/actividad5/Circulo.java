package actividad5;



public class Circulo implements Calculable{
    private double radio;

    public Circulo(double radio) {
        this.radio = radio;
    }

    @Override
    public double calcularArea() {
        return Math.PI * this.radio * this.radio;  // Fórmula del área del círculo: π * r^2
    }
}