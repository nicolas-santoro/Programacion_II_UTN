package empresa.logistica;



import java.util.ArrayList;


public class EmpresaDeLogistica {
    private ArrayList<TransportadorDePaquete> transportadores;
    
    public EmpresaDeLogistica() {
        this.transportadores = new ArrayList<>();
    }
    
    public void iniciarEntrega(String destino) {
        for (TransportadorDePaquete transportador : this.transportadores){
            transportador.transportarPaquete(destino);
        }
    }

    public void agregarTransportador(TransportadorDePaquete nuevoTransportador) {
        if (!this.transportadores.contains(nuevoTransportador)) {
            this.transportadores.add(nuevoTransportador);

            System.out.println("Transportador agregado con exito!");
            System.out.println("");
        } 
        
        else {
            System.out.println("El transportador ya existe en la lista...");
            System.out.println("");
        }
    }
}