package empresa.logistica;



public class Principal {
    public static void main(String[] args) {
        // Crear la empresa de logística
        EmpresaDeLogistica empresa = new EmpresaDeLogistica();

        // Crear diferentes tipos de transportadores
        CamionDeReparto camion = new CamionDeReparto();
        DronDeEntrega dron = new DronDeEntrega();
        PersonaMensajera mensajero = new PersonaMensajera();

        // Agregar transportadores a la lista
        empresa.agregarTransportador(camion);   // Debería agregar el camión
        empresa.agregarTransportador(dron);     // Debería agregar el dron
        empresa.agregarTransportador(mensajero); // Debería agregar al mensajero

        // Intentar agregar un transportador duplicado
        empresa.agregarTransportador(camion);   // Debería decir que ya existe

        // Iniciar la entrega
        empresa.iniciarEntrega("Buenos Aires");
    }
}