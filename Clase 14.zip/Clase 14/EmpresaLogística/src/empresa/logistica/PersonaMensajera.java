package empresa.logistica;



public class PersonaMensajera implements TransportadorDePaquete {
    @Override
    public void transportarPaquete(String destino) {
        System.out.println("El mensajero entregara el paquete en: " + destino);
        System.out.println("\n");
    }
}