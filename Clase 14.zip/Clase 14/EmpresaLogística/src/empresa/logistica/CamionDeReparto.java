package empresa.logistica;



public class CamionDeReparto extends Vehiculo implements TransportadorDePaquete{
    public void conducirRapido() {
        System.out.println("El camion esta entregando el paquete a gran velocidad...");
    }

    @Override
    public void transportarPaquete(String destino) {
        super.cargarPaquete();
        conducirRapido();
        System.out.println("El paquete sera entregado en: " + destino);
        System.out.println("\n");
    }
}