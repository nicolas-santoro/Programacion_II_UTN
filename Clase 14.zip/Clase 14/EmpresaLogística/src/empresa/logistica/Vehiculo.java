package empresa.logistica;



public class Vehiculo {
    public void cargarPaquete() {
        System.out.println("Se esta cargando un paquete en el vehiculo...");
    }
}