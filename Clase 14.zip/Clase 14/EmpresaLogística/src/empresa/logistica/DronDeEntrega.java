package empresa.logistica;



public class DronDeEntrega extends DispositivoElectronico implements TransportadorDePaquete {
    @Override
    public void encender() {
        System.out.println("El dron se esta encendiendo...");
    }

    @Override
    public void transportarPaquete(String destino) {
        encender();
        System.out.println("El paquete sera entregado en: " + destino);
        System.out.println("\n");
    }
}