package empresa.logistica;



public class DispositivoElectronico {
    public void encender() {
        System.out.println("Enciendiendo el dispositivo...");
    }
}