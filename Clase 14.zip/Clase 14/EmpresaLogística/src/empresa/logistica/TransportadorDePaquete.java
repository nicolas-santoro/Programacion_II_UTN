package empresa.logistica;



public interface TransportadorDePaquete {
    void transportarPaquete(String destino);
}