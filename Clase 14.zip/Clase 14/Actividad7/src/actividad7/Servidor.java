package actividad7;



public class Servidor {
    private Transferencia transferencia;

    public Servidor(Transferencia transferencia) {
        this.transferencia = transferencia;
    }

    public void realizarSubida(String archivo) {
        System.out.println("Iniciando subida de archivo: " + archivo);
        
        this.transferencia.subir(archivo);  // Llamada al método subir de la transferencia
    }

    public void realizarBajada(String archivo) {
        System.out.println("Iniciando bajada de archivo: " + archivo);
        
        this.transferencia.bajar(archivo);  // Llamada al método bajar de la transferencia
    }
}