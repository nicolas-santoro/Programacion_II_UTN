package actividad7;



public interface Transferencia {
    void subir(String archivo);  // Método para subir archivos
    void bajar(String archivo);  // Método para bajar archivos
}