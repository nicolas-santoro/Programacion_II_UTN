package actividad7;



public class FTPTransferencia implements Transferencia{
    @Override
    public void subir(String archivo) {
        System.out.println("Subiendo archivo " + archivo + " mediante FTP...");
        System.out.println("\n");
    }

    @Override
    public void bajar(String archivo) {
        System.out.println("Bajando archivo " + archivo + " mediante FTP...");
        System.out.println("\n");
    }
}