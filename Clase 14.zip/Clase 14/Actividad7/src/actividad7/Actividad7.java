package actividad7;



public class Actividad7 {
    public static void main(String[] args) {
        //Crear una instancia de FTPTransferencia y procesar mediante el Servidor
        FTPTransferencia ftp = new FTPTransferencia();
        Servidor servidorFTP = new Servidor(ftp);
        servidorFTP.realizarSubida("archivo1.txt");
        servidorFTP.realizarBajada("archivo2.txt");

        // Crear una instancia de HTTPTransferencia y procesar mediante el Servidor
        HTTPTransferencia http = new HTTPTransferencia();
        Servidor servidorHTTP = new Servidor(http);
        servidorHTTP.realizarSubida("imagen.png");
        servidorHTTP.realizarBajada("video.mp4");
    }
}