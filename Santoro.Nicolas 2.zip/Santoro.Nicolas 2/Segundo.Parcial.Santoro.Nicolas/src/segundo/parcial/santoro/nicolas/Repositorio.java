package segundo.parcial.santoro.nicolas;



import java.util.ArrayList;


public interface Repositorio<T> {
    boolean agregar(T elemento);
    boolean eliminar(T elemento);
    ArrayList<T> obtenerTodos();
}