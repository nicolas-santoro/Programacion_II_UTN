package segundo.parcial.santoro.nicolas;



public enum Categoria {
    ELECTRONICA,
    MODA,
    HOGAR,
    BELLEZA
}