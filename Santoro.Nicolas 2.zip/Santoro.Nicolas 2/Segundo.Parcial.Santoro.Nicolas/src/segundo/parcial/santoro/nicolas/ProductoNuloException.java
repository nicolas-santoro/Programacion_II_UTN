package segundo.parcial.santoro.nicolas;



public class ProductoNuloException extends Exception{
    public ProductoNuloException(String mensaje) {
        super(mensaje);
    }
}