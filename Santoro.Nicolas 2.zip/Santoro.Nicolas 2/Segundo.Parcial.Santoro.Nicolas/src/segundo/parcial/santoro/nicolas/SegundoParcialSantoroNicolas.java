package segundo.parcial.santoro.nicolas;

import java.io.IOException;
import java.util.Collections;



public class SegundoParcialSantoroNicolas {
    public static void main(String[] args) throws IOException, ClassNotFoundException {
        Estante estante = new Estante();

        Producto laptop = new Producto("Laptop", 1200.99, Categoria.ELECTRONICA, "11111");
        Producto Sillon = new Producto("Sillon", 450.50, Categoria.HOGAR, "22222");
        Producto Remera = new Producto("Remera", 25.99, Categoria.MODA, "33333");
        Producto maquillaje = new Producto("Maquillaje", 75.00, Categoria.BELLEZA, "44444");
        Producto televisor = new Producto("Televisor", 800.00, Categoria.ELECTRONICA, "55555");

        estante.agregar(laptop);
        estante.agregar(Sillon);
        estante.agregar(Remera);
        estante.agregar(maquillaje);
        estante.agregar(televisor);

        estante.agregar(null);

        System.out.println("Productos en el estante:");
        estante.mostrarProductos();

        System.out.println("\nEstante ordenado por nombre:");
        Collections.sort(estante.obtenerTodos());
        estante.mostrarProductos();

        System.out.println("\nEstante ordenado por codigo de barras:");
        estante.ordenarPorCodigoBarra();
        estante.mostrarProductos();

        System.out.println("\nEstante ordenado por precio:");
        estante.ordenarPorPrecio();
        estante.mostrarProductos();

        System.out.println("\nEstante ordenado por categoria:");
        estante.ordenarPorCategoria();
        estante.mostrarProductos();

        Producto productoNoExistente = new Producto("Telefono", 150.00, Categoria.ELECTRONICA, "66666");
        estante.eliminar(productoNoExistente);

        estante.eliminar(televisor);

        System.out.println("\nProductos despues de eliminacion:");
        estante.mostrarProductos();

        // Serializar el estante en un archivo
        estante.serializarBinario(estante, "productos.dat");

        // Deserializar desde el archivo
        Estante estanteDeserializado = estante.deserializarBinario("productos.dat");

        // Mostrar los productos deserializados
        System.out.println("\nProductos deserializados:");
        if (estanteDeserializado != null) {
            estanteDeserializado.mostrarProductos();
        }
    } 
}