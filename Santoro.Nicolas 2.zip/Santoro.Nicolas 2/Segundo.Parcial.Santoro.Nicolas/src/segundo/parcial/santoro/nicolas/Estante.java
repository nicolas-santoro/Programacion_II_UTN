package segundo.parcial.santoro.nicolas;



import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;


public class Estante implements Repositorio<Producto>, Iterable<Producto>, Serializadora<Estante>, Serializable{
    private ArrayList<Producto> productos;
 
    public Estante() {
        this.productos = new ArrayList<>();
    }

    @Override
    public boolean agregar(Producto producto) {
        try {
            if (producto == null) {
                throw new ProductoNuloException("El producto no puede ser nulo...");
            }
            
            this.productos.add(producto);
            
            
            return true;
        } 
        
        catch (ProductoNuloException e) {
            System.out.println(e.getMessage());
            
            
            return false;
        }
    }

    @Override
    public boolean eliminar(Producto producto) {
        try {
            if (!this.productos.contains(producto)) {
                throw new ProductoNoEncontradoException("El producto no se encuentra en el estante...");
            }
            
            this.productos.remove(producto);
            
            
            return true;
        } 
        
        catch (ProductoNoEncontradoException e) {
            System.out.println(e.getMessage());
            
            
            return false;
        }
    }

    @Override
    public ArrayList<Producto> obtenerTodos() {
        try {
            if (this.productos.isEmpty()) {
                throw new EstanteVacioException("El estante esta vacio...");
            }
            
            
            return this.productos;
        } 
        
        catch (EstanteVacioException e) {
            System.out.println(e.getMessage());
            
            
            return new ArrayList<>();
        }
    }

    @Override
    public Iterator<Producto> iterator() {
        return this.productos.iterator();
    }
    
    public void ordenarPorNombre() {
        this.productos.sort(Comparator.comparing(Producto::getNombre));
    }

    public void ordenarPorCodigoBarra() {
        this.productos.sort(Comparator.comparing(Producto::getCodigoBarra));
    }

    public void ordenarPorPrecio() {
        this.productos.sort(Comparator.comparingDouble(Producto::getPrecio));
    }

    public void ordenarPorCategoria() {
        this.productos.sort(Comparator.comparing(Producto::getCategoria));
    }
    
    @Override
    public void serializarBinario(Estante estante, String rutaArchivo) throws IOException {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(rutaArchivo))) {
            oos.writeObject(estante);
        }
    }

    @Override
    public Estante deserializarBinario(String rutaArchivo) throws IOException, ClassNotFoundException {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(rutaArchivo))) {
            return (Estante) ois.readObject();
        }
    }
    
    public void mostrarProductos() {
        for (Producto producto : this.productos) {
            System.out.println(producto.toString());
        }
    }
}