package segundo.parcial.santoro.nicolas;



public class EstanteVacioException extends Exception {
    public EstanteVacioException(String mensaje) {
        super(mensaje);
    }
}