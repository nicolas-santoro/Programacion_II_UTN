package segundo.parcial.santoro.nicolas;




import java.io.IOException;


public interface Serializadora<T> {
    void serializarBinario(T objeto, String rutaArchivo) throws IOException;
    T deserializarBinario(String rutaArchivo) throws IOException, ClassNotFoundException;
}