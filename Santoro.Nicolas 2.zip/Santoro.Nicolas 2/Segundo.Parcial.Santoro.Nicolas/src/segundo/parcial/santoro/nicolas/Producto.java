package segundo.parcial.santoro.nicolas;



import java.io.Serializable;


public class Producto implements Comparable<Producto>, Serializable {
    private String nombre;
    private double precio;
    private Categoria categoria;
    private String codigoBarra;

     public Producto(String nombre, double precio, Categoria categoria, String codigoBarra) {
        this.nombre = nombre;
        this.precio = precio;
        this.categoria = categoria;
        this.codigoBarra = codigoBarra;
    }
     
     public String getNombre() {
        return this.nombre;
    }
     
     public double getPrecio() {
        return this.precio;
    }
     
     public Categoria getCategoria() {
        return this.categoria;
    }
     
     public String getCodigoBarra() {
        return this.codigoBarra;
    }
    
    @Override
    public int compareTo(Producto otroProducto) {
        return this.nombre.compareTo(otroProducto.nombre);
    }
    
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        
        sb.append("Producto{")
          .append("nombre:'").append(this.nombre).append("', ")
          .append("precio:").append(this.precio).append(", ")
          .append("categoria:'").append(this.categoria).append("', ")
          .append("codigo de barra:'").append(this.codigoBarra).append("'")
          .append('}');
        
        
        return sb.toString();
    }
}