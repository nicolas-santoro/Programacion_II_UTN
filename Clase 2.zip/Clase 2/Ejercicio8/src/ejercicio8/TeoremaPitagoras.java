package ejercicio8;



public class TeoremaPitagoras {
    public static double calcularHipotenusa(double base, double altura){
        double hipotenusa = Math.sqrt(Math.pow(base, 2) + Math.pow(altura, 2));
        
        return hipotenusa;
    }
}
