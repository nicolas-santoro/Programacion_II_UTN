package ejercicio8;



import java.util.Scanner;


public class Ejercicio8 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        
        System.out.print("Ingrese la longitud de la base del triangulo: ");
        double longitudBase = scanner.nextDouble();
        System.out.print("Ingrese la longitud de la altura del triangulo: ");
        double longitudAltura= scanner.nextDouble();
        
        double hipotenusa = TeoremaPitagoras.calcularHipotenusa(longitudBase, longitudAltura);
        
        System.out.println("La hipotenusa de tu triangulo es de: " + hipotenusa + " centimetros.");
    }
}