package ejercicio5;



public class Tabla {
    public static String tablaMultiplicar(int numero){
        StringBuilder tabla = new StringBuilder();
        
        System.out.println("Tabla de multiplicar del " + numero + ":");
        
        for (int i = 1; i <= 10; i++){
            tabla.append(numero).append(" X ").append(i).append(" = ").append(numero * i).append("\n");
        }
        
        return tabla.toString();
    }
}
