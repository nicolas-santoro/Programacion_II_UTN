package ejercicio5;


import java.util.Scanner;


public class Ejercicio5 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.print("Ingrese un numero: ");
        int numero = scanner.nextInt();
        
        String tabla = Tabla.tablaMultiplicar(numero);
        
        System.out.println(tabla);
    }
}