package ejercicio3;



import java.util.Scanner;


public class ValidarRespuesta {
    public static boolean validarS_N(String opcion) {
        Scanner scanner = new Scanner(System.in);
        
        boolean respuesta = true;

        
        while (true) {
            if ("N".equalsIgnoreCase(opcion)) {
                respuesta = false;
                
                break;
            } 
            
            else if ("S".equalsIgnoreCase(opcion)) {
                respuesta = true;
                
                break;
            } 
            
            else {
                System.out.println("Respuesta invalida...");
                System.out.print("Ingrese su opcion (S / N): ");
                opcion = scanner.nextLine();
            }
        }

        
        return respuesta;
    }
}