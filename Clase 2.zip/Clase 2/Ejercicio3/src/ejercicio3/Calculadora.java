package ejercicio3;



public class Calculadora {
    public static double calcular(double operando1, double operando2, String operacion){
        double resultado = 0;
        
        
        switch (operacion) {
            case "+":
                resultado = operando1 + operando2;
                
                break;
                
            case "-":
                resultado = operando1 - operando2;
                
                break;
                
            case "*":
                resultado = operando1 * operando2;
                
                break;
                
            case "/":
                if (Calculadora.validar(operando2)){
                    resultado = operando1 / operando2;
                }
                
                else{
                    System.out.println("La division no fue posible, no se puede divir por 0...");
                }
                
                break;
                
            default:
                break;
        }
        
        
        return resultado;
    }
    
    private static boolean validar(double operando2){
        boolean distincion;
        
        if (operando2 != 0){
            distincion = true;
        }
        
        else{
            distincion = false;
        }
        
        
        return distincion;
    }
}