package ejercicio3;



import java.util.Scanner;


public class Ejercicio3 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        boolean continuar = true;
        
        
        while (continuar){
            System.out.print("Ingrese el primer operador: ");
            double operador1 = scanner.nextInt();

            System.out.print("Ingrese el segundo operador: ");
            double operador2 = scanner.nextInt();

            System.out.print("Ingrese la operacion que quiera realizar: ");
            String operacion = scanner.next();

            double resultado = Calculadora.calcular(operador1, operador2, operacion);

            System.out.println("El resultado de la " + operacion + " es: " + resultado);


            System.out.println("Desea continuar? (S / N): ");
            String respuesta = scanner.next();
            
           continuar = ValidarRespuesta.validarS_N(respuesta);
        }
    }
}