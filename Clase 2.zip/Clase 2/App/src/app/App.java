package app;



public class App {
    public static void main(String[] args) {
        MiClase.cadena = "Hola";
        MiClase.entero = 44;
        
        MiClase.Guardar(88, "Chau");
        MiClase.Mostrar();
    }   
}