package app;



public class MiClase {
    public static int entero;
    public static String cadena;
    
    public static void Mostrar(){
        System.out.println(MiClase.entero);
        System.out.println(MiClase.cadena);
    }
    
    public static void Guardar(int entero, String cadena){
        MiClase.entero = entero;
        MiClase.cadena = cadena;
        }
        
        
    public int otroEntero;
    public String otraCadena;
}