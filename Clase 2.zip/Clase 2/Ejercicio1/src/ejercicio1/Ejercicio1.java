package ejercicio1;



import java.util.Scanner;


public class Ejercicio1 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int min = Integer.MAX_VALUE;
        int max = Integer.MIN_VALUE;
        int suma = 0;
        int count = 0;
        
        for (int i = 0; i < 10; i++) {
            System.out.print("Ingresa un numero entero entre -100 y 100: ");
            int numero = scanner.nextInt();
            
            // Validar que el número esté en el rango permitido
            if (Validadora.validar(numero, -100, 100)) {
                if (numero < min) {
                    min = numero;
                }
                
                if (numero > max) {
                    max = numero;
                }
                
                suma += numero;
                count++;
            } 
            else {
                System.out.println("Numero fuera de rango. Intentalo de nuevo.");
                i--; // Repetir la iteración si el número no es válido
            }
        }
        
        // Calcular el promedio
        double promedio = (double) suma / count;
        
        // Mostrar resultados
        System.out.println("Valor minimo ingresado: " + min);
        System.out.println("Valor maximo ingresado: " + max);
        System.out.println("Promedio de los valores ingresados: " + promedio);
    }
}
