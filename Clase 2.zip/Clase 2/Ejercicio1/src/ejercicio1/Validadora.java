package ejercicio1;



public class Validadora {
    public static boolean validar(int valor, int min, int max) {
        return valor >= min && valor <= max;
    }
}