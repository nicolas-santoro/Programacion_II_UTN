package ejercicio9;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class Ejercicio9 {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy"); // Formato para entrada de fechas
        
        System.out.print("Ingrese su fecha de nacimiento (dd/MM/yyyy): ");
        String fechaNacimientoString = scanner.nextLine();
        
        // Convertir la cadena de entrada a un objeto LocalDate
        LocalDate fechaNacimiento = LocalDate.parse(fechaNacimientoString, formatter);
        
        // Calcular el número de días vividos utilizando el método del Proyecto 1
        long diasVividos = PasaTiempo.calcularDiasDesde(fechaNacimiento);
        
        // Mostrar el resultado
        System.out.println("Numero de días vividos: " + diasVividos);
        
        scanner.close(); // Cerrar el scanner
    }
}