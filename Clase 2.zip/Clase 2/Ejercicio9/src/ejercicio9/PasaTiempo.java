package ejercicio9;



import java.time.LocalDate;
import java.time.temporal.ChronoUnit;


public class PasaTiempo {
    public static long calcularDiasDesde(LocalDate fecha) {
        LocalDate hoy = LocalDate.now(); // Obtener la fecha actual
        
        
        return ChronoUnit.DAYS.between(fecha, hoy); // Calcular la diferencia en días
    }
}