package ejercicio7;



import java.util.Scanner;


public class Ejercicio7 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.println("Calculadora de areas");
        System.out.println("Cuadrado / Triangulo / Circulo");
        System.out.print("Eliga de que figura quiere encontrar su area (CU / TI / CI:  ");
        String opcion = scanner.next();
        
        if (opcion.equalsIgnoreCase("CU")){
            System.out.print("Ingrese la longitud del lado del cuadrado: ");
            double longitud = scanner.nextDouble();
            
            double area = CalculadoraDeArea.calcularAreaCuadrado(longitud);
            
            System.out.println("El area de su cuadrado es de: " + area);
        }
        
        else if (opcion.equalsIgnoreCase("TI")){
            System.out.print("Ingrese la longitud de la base del triangulo: ");
            double longitudBase = scanner.nextDouble();
            System.out.print("Ingrese la longitud de la altura del triangulo: ");
            double longitudAltura= scanner.nextDouble();
            
            double area = CalculadoraDeArea.calcularAreaTriangulo(longitudBase, longitudAltura);
            
            System.out.println("El area de su triangulo es de: " + area);
        }
        
        else if (opcion.equalsIgnoreCase("CI")){
            System.out.print("Ingrese el radio del circulo: ");
            double radio = scanner.nextDouble();
            
            double area = CalculadoraDeArea.calcularAreaCirculo(radio);
            
            System.out.println("El area de su circulo es de: " + area);
        }
        
        else {
            System.out.println("Opcion invalida...");
        }
    } 
}