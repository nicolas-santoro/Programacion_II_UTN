package ejercicio7;



public class CalculadoraDeArea {
    public static double calcularAreaCuadrado(double longitudLado){
        return Math.pow(longitudLado, 2);
    }
    
    public static double calcularAreaTriangulo(double base, double altura){
        return (base * altura) / 2;
    }
    
    public static double calcularAreaCirculo(double radio){
        return Math.PI * Math.pow(radio, 2);
    }
}