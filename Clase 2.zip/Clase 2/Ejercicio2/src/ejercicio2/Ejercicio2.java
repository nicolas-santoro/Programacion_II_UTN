package ejercicio2;



import java.util.Scanner;


public class Ejercicio2 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.print("Ingresa el primer numero: ");
        int numero1 = scanner.nextInt();
        System.out.print("Ingresa el segundo numero: ");
        int numero2 = scanner.nextInt();
        
        int resultado = numero1 + numero2;
        System.out.println("El resultado es: " + resultado);
        
        System.out.print("Desea continuar? (S / N): ");
        String respuesta = scanner.next();
        
        while (ValidarRespuesta.validarS_N(respuesta)){
            System.out.print("Ingresa un numero extra: ");
            int extra = scanner.nextInt();

            int resultadoTotal = resultado + extra;
            System.out.println("El resultado es: " + resultadoTotal);

            System.out.print("Desea continuar? (S / N): ");
            respuesta = scanner.next(); // Aquí se actualiza la respuesta
        }
    }
}