package ejercicio6;



public class Factorial {
    public static int calcularFactorial(int numero){
        int factorial = 1;
        
        for (int i = 1; i <= numero; i++){
            factorial *= i;
        }
        
        return factorial;
    }
}