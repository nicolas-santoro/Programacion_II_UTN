package ejercicio6;



import java.util.Scanner;


public class Ejercicio6 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.print("Ingrese un numero: ");
        int numero = scanner.nextInt();
        
        int factorial = Factorial.calcularFactorial(numero);
        System.out.println("El factorial de " + numero + " es: " + factorial);
    }
}