package ejercicio4;

import java.util.Scanner;

public class Ejercicio4 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.print("Elige que numero quieres covertir (Decimal / Binario): ");
        String opcion = scanner.next();
       
        
        if (opcion.equalsIgnoreCase("Decimal")){
            System.out.print("Ingresa el numero decimal a convertir: ");
            double numeroDecimal = scanner.nextInt();
            
           String numeroConvertido = Conversora.decimalBinario(numeroDecimal);
           
            System.out.println("Numero decimal ingresado: " + numeroDecimal);
            System.out.println("Numero convertido a binario: " + numeroConvertido);
        }
        else if (opcion.equalsIgnoreCase("Binario")){
            System.out.print("Ingresa el numero binario a convertir: ");
            String numeroBinario = scanner.next();
            
            double numeroConvertido;
            numeroConvertido = Conversora.binarioDecimal(numeroBinario);
            
            System.out.println("Numero ingresado: " + numeroBinario);
            System.out.println("Numero convertido: " + numeroConvertido);
        }
    }
}