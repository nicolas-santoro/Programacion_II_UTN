package ejercicio4;



public class Conversora {
    public static String decimalBinario(double decimal){
        if (decimal <= 0){
            System.out.println("Número inválido...");
        }
        
        // Convierte el número decimal a binario utilizando la clase Integer
        int entero = (int) decimal;
        String binario = Integer.toBinaryString(entero);

        // Manejo de la parte fraccionaria
        double fraccion = decimal - entero;
        if (fraccion > 0) {
            binario += ".";
            while (fraccion > 0) {
                fraccion *= 2;
                int bit = (int) fraccion;
                binario += bit;
                fraccion -= bit;
            }
        }

        return binario;
    }
    
// Método de clase para convertir de binario a decimal
    public static double binarioDecimal(String binario) {
        if (binario == null || binario.isEmpty()) {
            System.out.println("El número binario no puede estar vacío.");
        }

        // Dividir la cadena en parte entera y parte fraccionaria
        String[] partes = binario.split("\\.");
        String parteEntera = partes[0];
        String parteFraccionaria = partes.length > 1 ? partes[1] : "";

        // Convertir la parte entera a decimal
        double decimalEntero = 0;
        for (int i = 0; i < parteEntera.length(); i++) {
            char bit = parteEntera.charAt(parteEntera.length() - 1 - i);
            
            if (bit == '1') {
                decimalEntero += Math.pow(2, i);
            }
            
            else if (bit != '0') {
                System.out.println("El número binario contiene caracteres no válidos.");
            }
        }

        // Convertir la parte fraccionaria a decimal
        double decimalFraccionario = 0;
        for (int i = 0; i < parteFraccionaria.length(); i++) {
            char bit = parteFraccionaria.charAt(i);
            
            if (bit == '1') {
                decimalFraccionario += Math.pow(2, -(i + 1));
            } 
            
            else if (bit != '0') {
                System.out.println("El número binario contiene caracteres no válidos.");
            }
        }

        return decimalEntero + decimalFraccionario;
    }
}