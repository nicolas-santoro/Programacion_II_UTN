/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package santoro.nicolas;

/**
 *
 * @author Nicolas
 */
import java.util.ArrayList;
public class Biblioteca {
     private int capacidad;
    private ArrayList<Libro> libros;

    public Biblioteca() {
        this.capacidad = 3;
        this.libros = new ArrayList<>(capacidad);
    }

    public Biblioteca(int capacidad) {
        this.capacidad = capacidad;
        this.libros = new ArrayList<>(capacidad);
    }

    public boolean sonIguales(Libro libro) {
        return libros.contains(libro);
    }

    public void agregar(Libro libro) {
        if (libros.size() >= capacidad) {
            System.out.println("La biblioteca esta llena.");
        } 
        else if (sonIguales(libro)) {
            System.out.println("El libro ya existe en la biblioteca.");
        } 
        else {
            libros.add(libro);
        }
    }

    private double getPrecio(PrecioLibro tipo) {
        double total = 0.0;
        for (Libro libro : libros) {
            switch (tipo) {
                case MANUALES:
                    if (libro instanceof Manual) total += libro.getPrecio();
                    break;
                case NOVELAS:
                    if (libro instanceof Novela) total += libro.getPrecio();
                    break;
                case TODOS:
                    total += libro.getPrecio();
                    break;
            }
        }
        return total;
    }

    public double getPrecioDeManuales() {
        return getPrecio(PrecioLibro.MANUALES);
    }

    public double getPrecioDeNovelas() {
        return getPrecio(PrecioLibro.NOVELAS);
    }

    public double getPrecioTotal() {
        return getPrecio(PrecioLibro.TODOS);
    }

    public static String mostrar(Biblioteca biblioteca) {
        StringBuilder sb = new StringBuilder();
        sb.append("Capacidad: ").append(biblioteca.capacidad).append("\nLibros:\n");
        for (Libro libro : biblioteca.libros) {
            sb.append(libro.toString()).append("\n");
        }
        return sb.toString();
    }
}
