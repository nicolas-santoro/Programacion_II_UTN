/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package santoro.nicolas;

/**
 *
 * @author Nicolas
 */
public class Autor {
    private String nombre;
    private String apellido;

    public Autor(String nombre, String apellido) {
        this.nombre = nombre;
        this.apellido = apellido;
    }

    public static boolean sonIguales(Autor a1, Autor a2) {
        return a1.nombre.equals(a2.nombre) && a1.apellido.equals(a2.apellido);
    }

    public String getNombreApellido() {
        return nombre + " - " + apellido;
    }
}
