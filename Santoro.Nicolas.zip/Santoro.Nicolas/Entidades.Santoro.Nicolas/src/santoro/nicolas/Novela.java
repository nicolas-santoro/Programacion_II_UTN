/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package santoro.nicolas;

/**
 *
 * @author Nicolas
 */
public class Novela extends Libro{
    private Genero genero;

    public Novela(String titulo, float precio, Autor autor, Genero genero) {
        super(titulo, precio, autor);
        this.genero = genero;
    }

    @Override
    public String toString() {
        return super.toString() + ", Genero: " + genero;
    }

    @Override
    public boolean equals(Object obj) {
        if (!super.equals(obj)) return false;
        if (!(obj instanceof Novela)) return false;
        Novela otro = (Novela) obj;
        return this.genero == otro.genero;
    }
}
