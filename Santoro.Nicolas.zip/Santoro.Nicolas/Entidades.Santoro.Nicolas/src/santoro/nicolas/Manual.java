/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package santoro.nicolas;

/**
 *
 * @author Nicolas
 */
public class Manual extends Libro {
    private Tipo tipo;

    public Manual(String titulo, float precio, String nombre, String apellido, Tipo tipo) {
        super(titulo, precio, nombre, apellido);
        this.tipo = tipo;
    }

    @Override
    public String toString() {
        return super.toString() + ", Tipo: " + tipo;
    }

    @Override
    public boolean equals(Object obj) {
        if (!super.equals(obj)) return false;
        if (!(obj instanceof Manual)) return false;
        Manual otro = (Manual) obj;
        return this.tipo == otro.tipo;
    }
}
