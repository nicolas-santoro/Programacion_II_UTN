/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package santoro.nicolas;

/**
 *
 * @author Nicolas
 */
import java.util.Random;
public class Libro {
    protected Autor autor;
    protected int cantidadDePaginas;
    protected String titulo;
    protected float precio;
    protected static Random generadorDePaginas = new Random();

    static {
        generadorDePaginas = new Random();
    }

    public Libro(String titulo, float precio, Autor autor) {
        this.titulo = titulo;
        this.precio = precio;
        this.autor = autor;
        this.cantidadDePaginas = 0; // Se inicializa en 0
    }

    public Libro(String titulo, float precio, String nombre, String apellido) {
        this(titulo, precio, new Autor(nombre, apellido));
    }

    public int getCantidadDePaginas() {
        if (cantidadDePaginas == 0) {
            cantidadDePaginas = generadorDePaginas.nextInt(882) + 31; // Entre 31 y 912
        }
        return cantidadDePaginas;
    }

    public float getPrecio() {
        return precio;
    }

    private static String mostrar(Libro libro) {
        return "Titulo: " + libro.titulo + ", Autor: " + libro.autor.getNombreApellido() +
               ", Paginas: " + libro.getCantidadDePaginas() + ", Precio: " + libro.precio;
    }

    public static boolean sonIguales(Libro l1, Libro l2) {
        return l1.titulo.equals(l2.titulo) && Autor.sonIguales(l1.autor, l2.autor);
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (!(obj instanceof Libro)) return false;
        Libro otro = (Libro) obj;
        return sonIguales(this, otro);
    }

    @Override
    public String toString() {
        return mostrar(this);
    }
}
