package santoro.nicolas;

/**
* Código generado por la app UXFtoJava by Charly Cimino
* @see https://github.com/CharlyCimino/uxf-to-java
*/
public class Novela {

    private Genero genero;
    Genero sinNombre;

    public void Manual(Tipo tipo1) {
        // Método a resolver...
    }

    public boolean equals() {
        // Método a resolver...
        return false;
    }

    public String toString() {
        // Método a resolver...
        return "";
    }

}