package santoro.nicolas;

/**
* Código generado por la app UXFtoJava by Charly Cimino
* @see https://github.com/CharlyCimino/uxf-to-java
*/
public class BIblioteca {

    private int capacidad;
    private ArrayList<Libro> libros;
    Libro sinNombre;

    public void Biblioteca() {
        // Método a resolver...
    }

    public void Biblioteca(int int1) {
        // Método a resolver...
    }

    public boolean sonIguales(Libro libro1) {
        // Método a resolver...
        return false;
    }

    public void agregar(Libro libro1) {
        // Método a resolver...
    }

    private float getPrecio(PrecioLibro preciolibro1) {
        // Método a resolver...
        return 0;
    }

    public double getPrecioDeManuales() {
        // Método a resolver...
        return 0;
    }

    public double getPrecioDeNovelas() {
        // Método a resolver...
        return 0;
    }

    public String mostrar(Biblioteca biblioteca1) {
        // Método a resolver...
        return "";
    }

}