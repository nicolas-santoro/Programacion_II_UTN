package santoro.nicolas;

/**
* Código generado por la app UXFtoJava by Charly Cimino
* @see https://github.com/CharlyCimino/uxf-to-java
*/
public class Manual {

    private Tipo tipo;
    Tipo sinNombre;

    public Manual(Tipo tipo1) {
        // Constructor a resolver...
    }

    public boolean equals() {
        // Método a resolver...
        return false;
    }

    public String toString() {
        // Método a resolver...
        return "";
    }

}