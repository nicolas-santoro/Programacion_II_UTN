package actividad5;

import Boligrafo.Boligrafo;



public class Actividad5 {
    public static void main(String[] args) {
        Boligrafo lapiceraAzul = new Boligrafo("azul", (short) 100);
        Boligrafo lapiceraRoja = new Boligrafo("rojo", (short) 50);
        Boligrafo lapiceraCeleste = new Boligrafo("celeste", (short) 1000);
        Boligrafo lapiceraAmarilla = new Boligrafo("amarillo", (short)  1000);
        Boligrafo lapiceraBlanca = new Boligrafo("blanco", (short)  1000);
        Boligrafo lapiceraVerde = new Boligrafo("verde", (short)  1000);
        Boligrafo lapiceraMarron = new Boligrafo("marron", (short)  1000);
        
        lapiceraRoja.recargar();
        
        lapiceraRoja.pintar(50);
        System.out.println("");
        lapiceraAzul.pintar(50);
        System.out.println("");
        System.out.println("");
        
        lapiceraCeleste.pintar(50);
        System.out.println("");
        lapiceraCeleste.pintar(50);
        System.out.println("");
        lapiceraCeleste.pintar(50);
        System.out.println("");
        lapiceraBlanca.pintar(23);
        lapiceraAmarilla.pintar(4);
        lapiceraBlanca.pintar(23);
        System.out.println("");
        lapiceraBlanca.pintar(22);
        lapiceraAmarilla.pintar(6);
        lapiceraBlanca.pintar(22);
        System.out.println("");
        lapiceraBlanca.pintar(22);
        lapiceraAmarilla.pintar(6);
        lapiceraBlanca.pintar(22);
        System.out.println("");
        lapiceraBlanca.pintar(23);
        lapiceraAmarilla.pintar(4);
        lapiceraBlanca.pintar(23);
        System.out.println("");
        lapiceraCeleste.pintar(50);
        System.out.println("");
        lapiceraCeleste.pintar(50);
        System.out.println("");
        lapiceraCeleste.pintar(50);
        System.out.println("");
    }
}