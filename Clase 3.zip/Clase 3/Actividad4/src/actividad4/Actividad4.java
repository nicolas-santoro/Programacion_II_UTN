package actividad4;



public class Actividad4 {
    public static void main(String[] args) {
        Estudiante estudiante1 = new Estudiante("Nerina", "Sanchez", "306650");
        Estudiante estudiante2 = new Estudiante("Leonardo", "Santoro", "312790");
        Estudiante estudiante3 = new Estudiante("Nicolas", "Santoro", "116675");
        
        estudiante1.setNotaPrimerParcial(2);
        estudiante1.setNotaSegundoParcial(2);
        
        estudiante2.setNotaPrimerParcial(10);
        estudiante2.setNotaSegundoParcial(10);
        
        estudiante3.setNotaPrimerParcial(4);
        estudiante3.setNotaSegundoParcial(5);
        
        estudiante1.mostrar();
        estudiante2.mostrar();
        estudiante3.mostrar();
    }
}