package actividad4;



import java.util.Random;


public class Estudiante {
    private final String nombre;
    private final String apellido;
    private final String legajo;
    private int notaPrimerParcial;
    private int notaSegundoParcial;
    
    private static final Random random;
    
    static{
         random = new Random();
    }

    public Estudiante(String nombre, String apellido, String legajo) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.legajo = legajo;
    }

    public void setNotaPrimerParcial(int notaPrimerParcial) {
        this.notaPrimerParcial = notaPrimerParcial;
    }

    public void setNotaSegundoParcial(int notaSegundoParcial) {
        this.notaSegundoParcial = notaSegundoParcial;
    }
    
    private double calcularPromedio(){
        return (notaPrimerParcial + notaSegundoParcial) / 2;
    }
    
    public int calcularNotaFinal(){
        int notaFinal = -1;
        
        if (notaPrimerParcial >= 4 && notaSegundoParcial >= 4){
            notaFinal = random.nextInt(10 - 6 + 1) + 6;
        }
   
        
        return notaFinal;
    }
    
    public void mostrar(){
        StringBuilder datos = new StringBuilder();
        
        datos.append("Estudiante: ").append(nombre).append(" ").append(apellido).append(". ").append(legajo).append( "\n");
        
        datos.append("Nota del primer y segundo parcial: ").append(notaPrimerParcial).append(". ").append(notaSegundoParcial).append( "\n");
        
        datos.append("Promedio: ").append(calcularPromedio()).append( "\n");
        
        if (calcularNotaFinal() == -1){
            datos.append("Nota final: ").append("Alumno desaprobado...").append( "\n");
        }
        else{
          datos.append("Nota final: ").append(calcularNotaFinal()).append( "\n");  
        }
        
        String datosTotales = datos.toString();
        
        System.out.println(datosTotales);
    }
}