package actividad2;


import java.util.Random;

public class AdivinarNumeros {
    private final int numeroSecreto;
    private int intentos;

    // Constructor que inicializa el número secreto y los intentos
    public AdivinarNumeros(){
        Random random = new Random();
        this.numeroSecreto = random.nextInt(100) + 1; // Número entre 1 y 100
        this.intentos = 0;
    }

    // Método para adivinar el número
    public String adivinar(int numero) {
        intentos++;
        if (numero < numeroSecreto) {
            return "Mayor";
        } 
        
        else if (numero > numeroSecreto) {
            return "Menor";
        } 
        
        else {
            return "Igual";
        }
    }

    // Getter para los intentos
    public int getIntentos() {
        return intentos;
    }

    // Getter para el número secreto
    public int getNumeroSecreto() {
        return numeroSecreto;
    }
}