package actividad2;



import java.util.Scanner;


public class Actividad2 {
    public static void main(String[] args) {
         Scanner scanner = new Scanner(System.in);
         AdivinarNumeros juego = new AdivinarNumeros();

        // Selección de nivel de dificultad
        System.out.println("Selecciona un nivel de dificultad: ");
        System.out.println("1. Facil (intentos ilimitados).");
        System.out.println("2. Medio (hasta 50 intentos).");
        System.out.println("3. Dificil (hasta 10 intentos).");
        
        int nivel = scanner.nextInt();
        int intentosMaximos = 0;

        switch (nivel) {
            case 1 -> intentosMaximos = Integer.MAX_VALUE; // Ilimitado
            case 2 -> intentosMaximos = 50;
            case 3 -> intentosMaximos = 10;
            default -> {
                System.out.println("Nivel no valido, eligiendo nivel facil...");
                intentosMaximos = Integer.MAX_VALUE;
            }
        }

        boolean acertado = false;
        while (!acertado && juego.getIntentos() < intentosMaximos) {
            System.out.print("Adivina un numero entre 1 y 100: ");
            int numero = scanner.nextInt();
            
            String resultado = juego.adivinar(numero);

            if (resultado.equals("Igual")) {
                acertado = true;
                System.out.println("Ganaste! El numero " + juego.getNumeroSecreto() +
                                   " lo adivinaste en " + juego.getIntentos() + " intentos!");
            } 
            
            else {
                System.out.println("El numero es " + resultado + ". Intentos: " + juego.getIntentos());
            }
        }

        if (!acertado) {
            System.out.println("Perdiste! El numero secreto era " + juego.getNumeroSecreto() + ".");
        }
    } 
}