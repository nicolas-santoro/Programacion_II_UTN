package actividad3;



import java.time.LocalDate;
import java.time.Period;


public class Persona {
    private String nombre;
    private LocalDate fechaDeNacimiento;
    private int dni;

    public Persona(String nombre, LocalDate fechaDeNacimiento, int dni) {
        this.nombre = nombre;
        this.fechaDeNacimiento = fechaDeNacimiento;
        this.dni = dni;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setFechaDeNacimiento(LocalDate fechaDeNacimiento) {
        this.fechaDeNacimiento = fechaDeNacimiento;
    }

    public void setDni(int dni) {
        this.dni = dni;
    }

    public String getNombre() {
        return nombre;
    }

    public LocalDate getFechaDeNacimiento() {
        return fechaDeNacimiento;
    }

    public int getDni() {
        return dni;
    }
    
    private int calcularEdad() {
        LocalDate fechaActual = LocalDate.now();
        
        Period periodo = Period.between(fechaDeNacimiento, fechaActual);
        
        
        return periodo.getYears();
    }
    
    public void mostrar(){
        // Usar getters para acceder a los atributos
        System.out.println("Nombre: " + getNombre());
        System.out.println("Fecha de nacimiento: " + getFechaDeNacimiento());
        System.out.println("Edad: " + calcularEdad() + " anios");
        System.out.println(" ");
    }
    
    public void esMayorDeEdad(){
        int edad = calcularEdad();
        if (edad < 18){
            System.out.println("Es menor de edad...");
            System.out.println(" ");
        }
        
        else{
            System.out.println("Es mayor de edad...");
            System.out.println("");
        }
    }
}