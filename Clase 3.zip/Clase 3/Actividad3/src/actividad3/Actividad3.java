package actividad3;



import java.time.LocalDate;


public class Actividad3 {
    public static void main(String[] args) {
        // Instanciar 3 objetos de la clase Persona
        Persona persona1 = new Persona("Juan Perez", LocalDate.of(1974, 5, 15), 12345678);
        Persona persona2 = new Persona("Ana Garcia", LocalDate.of(2008, 8, 22), 87654321);
        Persona persona3 = new Persona("Luis Fernandez", LocalDate.of(2000, 12, 30), 23456789);
        
        // Mostrar información de cada persona
        persona1.mostrar();
        persona1.esMayorDeEdad();
        
        persona2.mostrar();
        persona2.esMayorDeEdad();
        
        persona3.mostrar();
        persona3.esMayorDeEdad();
    }
}