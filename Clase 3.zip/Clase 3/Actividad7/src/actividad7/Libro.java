package actividad7;



public class Libro {
   private String titulo;
   private String autor;
   private boolean disponible;

    public Libro(String titulo, String autor, boolean disponible) {
        this.titulo = titulo;
        this.autor = autor;
        this.disponible = disponible;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public void setDisponible(boolean disponible) {
        this.disponible = disponible;
    }

    public String getTitulo() {
        return titulo;
    }

    public String getAutor() {
        return autor;
    }

    public boolean isDisponible() {
        return disponible;
    }
    
    public void mostrarInformacion(){
        String disponibilidad = "";
        
        if (disponible == true){
            disponibilidad = "disponible";
        }
        
        else{
            disponibilidad = "no disponible";
        }
        
        System.out.println("Titulo del libro: " + titulo);
        System.out.println("Autor del libro: " + autor);
        System.out.println("Disponibilidad del libro: " + disponibilidad);
    }
    
    public void prestar(){
        this.disponible = false;
    }
    public void devolver(){
        this.disponible = true;
    }
}