package actividad7;



public class Actividad7 {
    public static void main(String[] args) {
        Libro libro1 = new Libro("El Señor de los Anillos", "J. R. R. Tolkien", true);
        Libro libro2 = new Libro("Tren Bala", "Kotaro Isaka", false);
        Libro libro3 = new Libro("JoJo's Bizarre Adventure", "Hirohiko Araki", true);
        
        Lector lector1 = new Lector("Nerina");
        Lector lector2 = new Lector("Nicolas");
        Lector lector3 = new Lector("Leonardo");
        
        lector1.tomarPrestado(libro2);
        lector2.tomarPrestado(libro3);
        lector3.tomarPrestado(libro1);
           
        lector2.devolverLibro(libro3);
        lector2.mostrarInformacion();
    }
}