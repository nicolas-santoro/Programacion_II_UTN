package actividad7;



public class Lector {
    private String nombre;
    private Libro libroPrestado;

    public Lector(String nombre) {
        this.nombre = nombre;
    }
    
    public void tomarPrestado(Libro libroAPrestar){
        if (libroAPrestar.isDisponible()){
            this.libroPrestado = libroAPrestar;
            
            libroAPrestar.prestar();
        }
    }
    
    public void devolverLibro(Libro libroADevolver){
        libroADevolver.devolver();
        
        this.libroPrestado = null;
    }
    
    public void mostrarInformacion(){    
        System.out.println("Nombre: " + nombre);
        
        if (libroPrestado != null){
            System.out.println("Libro prestado: ");
            libroPrestado.mostrarInformacion();
        }
    }
}