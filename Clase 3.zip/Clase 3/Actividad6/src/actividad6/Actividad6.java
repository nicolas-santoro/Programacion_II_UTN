package actividad6;


import Geometria.Punto;
import Geometria.Rectangulo;


public class Actividad6 {
    public static void main(String[] args) {
        // Instanciar puntos
        Punto p1 = new Punto(2, 3);
        Punto p3 = new Punto(5, 6);

        // Crear un nuevo rectángulo
        Rectangulo rectangulo = new Rectangulo(p1, p3);

        // Imprimir valores de área y perímetro
        Rectangulo.mostrarDatosRectangulo(rectangulo);
    }  
}