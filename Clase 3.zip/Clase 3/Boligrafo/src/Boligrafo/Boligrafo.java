package Boligrafo;



public class Boligrafo {
    private final short CANTIDAD_MAXIMA_TINTA = 100;
    private String color;
    private short tinta;
    
    private static final String ROJO = "\033[31m";
    private static final String AZUL = "\033[34m";
    private static final String CELESTE = "\033[36m"; // Celeste
    private static final String AMARILLO = "\033[33m"; // Amarillo
    private static final String VERDE = "\033[32m";
    private static final String MARRON = "\033[33m";
    private static final String RESET = "\033[0m"; // Para restablecer el color al final

    public Boligrafo(String color, short tinta) {
        this.color = color;
        this.tinta = (short) tinta;
    }
    
    public String getColor() {
        return this.color;
    }

    public short getTinta() {
        return this.tinta;
    }

    private void setTinta(short cantidad) {
        // Calcular el nuevo nivel de tinta
        short nuevaTinta = (short) (this.tinta + cantidad);

        // Validar el nuevo nivel de tinta
        if (nuevaTinta > CANTIDAD_MAXIMA_TINTA) {
            this.tinta = CANTIDAD_MAXIMA_TINTA;
        } 
        
        else if (nuevaTinta < 0) {
            this.tinta = 0;
        } 
        
        else {
            this.tinta = nuevaTinta;
        }
    }
    
    public void recargar() {
        // Calcular la cantidad de tinta necesaria para alcanzar el máximo
        short cantidadNecesaria = (short) (CANTIDAD_MAXIMA_TINTA - tinta);
        
        setTinta(cantidadNecesaria);
        
        System.out.println("Se recargo " + cantidadNecesaria + " de tinta. Ahora tiene: " + tinta);
    }
    
    public void pintar(int gasto) {//gasto tiene que ser un short.
        // Verifica que el gasto sea positivo
        if (gasto <= 0) {
            System.out.println("El gasto debe ser un valor positivo...");
            
            
            return;
        }

        // Calcular el gasto real considerando la tinta restante
        int gastoActual = Math.min(gasto, tinta);

        // Aplicar el color ANSI antes de comenzar a imprimir
        String colorANSI = "celeste".equals(color) ? CELESTE : 
                "amarillo".equals(color) ? AMARILLO : 
                "azul".equals(color) ? AZUL : 
                "rojo".equals(color) ? ROJO : 
                "verde".equals(color) ? VERDE : 
                "marron".equals(color) ? MARRON : 
                "blanco".equals(color) ? RESET :
                RESET;
        System.out.print(colorANSI);

        // Imprimir los caracteres con el color especificado
        for (int i = 0; i < gastoActual; i++) {
            System.out.print("*");
        }

        // Restar la tinta gastada
        tinta -= gastoActual;

        // Restablecer el color al final del texto
        System.out.print(RESET);

        // Verificar si se ha agotado la tinta y mostrar un mensaje si es así
        if (tinta == 0) {
            System.out.println("\nNo queda mas tinta...");
        }
    }
}