package Geometria;



public class Rectangulo {
    private Punto vertice1;
    private Punto vertice2;
    private Punto vertice3;
    private Punto vertice4;

    private double area;
    private double perimetro;
    private boolean areaCalculada = false;
    private boolean perimetroCalculado = false;

    public Rectangulo(Punto vertice1, Punto vertice3) {
        this.vertice1 = vertice1;
        this.vertice3 = vertice3;
        calcularVertices();
    }

    private void calcularVertices() {
        double x1 = vertice1.getX();
        double y1 = vertice1.getY();
        double x3 = vertice3.getX();
        double y3 = vertice3.getY();

        double x2 = x3;
        double y2 = y1;
        double x4 = x1;
        double y4 = y3;

        this.vertice2 = new Punto(x2, y2);
        this.vertice4 = new Punto(x4, y4);
    }

    public Punto getVertice1() {
        return vertice1;
    }

    public Punto getVertice2() {
        return vertice2;
    }

    public Punto getVertice3() {
        return vertice3;
    }

    public Punto getVertice4() {
        return vertice4;
    }

    public double getArea() {
        if (!areaCalculada) {
            double base = Math.abs(vertice3.getX() - vertice1.getX());
            double altura = Math.abs(vertice3.getY() - vertice1.getY());
            area = base * altura;
            areaCalculada = true;
        }
        return area;
    }

    public double getPerimetro() {
        if (!perimetroCalculado) {
            double base = Math.abs(vertice3.getX() - vertice1.getX());
            double altura = Math.abs(vertice3.getY() - vertice1.getY());
            perimetro = 2 * (base + altura);
            perimetroCalculado = true;
        }
        return perimetro;
    }
    
    public static double calcularDistancia(Punto p1, Punto p2) {
        return Math.sqrt(Math.pow(p2.getX() - p1.getX(), 2) +
                         Math.pow(p2.getY() - p1.getY(), 2));
    }

    // Método estático para mostrar todos los datos del rectángulo
    public static void mostrarDatosRectangulo(Rectangulo rectangulo) {
        System.out.println(rectangulo);
        System.out.println("Area: " + rectangulo.getArea());
        System.out.println("Perimetro: " + rectangulo.getPerimetro());
    }
}