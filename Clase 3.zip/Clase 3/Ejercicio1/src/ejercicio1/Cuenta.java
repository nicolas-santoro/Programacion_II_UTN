package ejercicio1;



public class Cuenta{
   private final String titular;
   private double cantidad;

    public Cuenta(String titular, double cantidad){
        this.titular = titular;
        this.cantidad = cantidad;
    }

    public String getTitular(){
        return titular;
    }

    public double getCantidad(){
        return cantidad;
    }
    
    public String mostrar(){
        return "El titular es " + this.titular + ", y su saldo es de $" + this.cantidad;
    }
    
    public void ingresar(double valor){
        if (valor >= 0){
            this.cantidad += valor;
        }
        else{
            System.out.println("No se admiten valores negativos...");
        }
    }
    
    public void retirar(double valor){
        this.cantidad -= valor;
        
        if (this.cantidad < 0){
            this.cantidad = 0;
        }
    }
}