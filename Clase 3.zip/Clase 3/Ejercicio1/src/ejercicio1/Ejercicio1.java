package ejercicio1;



public class Ejercicio1 {
    public static void main(String[] args) {
        Cuenta cuenta1 = new Cuenta("Nicolas", 40000);
        
        cuenta1.ingresar(6000);
        
        cuenta1.retirar(11000);
                
        System.out.println(cuenta1.mostrar());
    }
}