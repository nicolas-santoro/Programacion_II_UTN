/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package app;

import java.util.Scanner;

/**
 *
 * @author Nicolas
 */
public class App {
    public static void main(String[] args) {
        System.out.println("Hola Mundo");
        
        Double algo;
        
        Scanner input = new Scanner(System.in);
        
        algo = input.nextDouble();
        
        System.out.println("Valor agregado: " + algo);
        
        input.close();
    }
}