package actividad3;



public class Tempera {
    private Color color;
    private String marca;
    private int cantidad;

    public Tempera(Color color, String marca, int cantidad) {
        this.color = color;
        this.marca = marca;
        this.cantidad = cantidad;
    }


    private String mostrar() {
        return "Color: " + this.color + ", marca: " + this.marca + ", cantidad: " + this.cantidad;
    }

    public int getCantidad() {
        return cantidad;
    }

    public static String mostrar(Tempera tempera1) {
        return tempera1.mostrar();
    }

    public static boolean sonIguales(Tempera tempera1, Tempera tempera2) {
        return tempera1.color.equals(tempera2.color) && tempera1.marca.equals(tempera2.marca);
    }

    public static boolean sonDistintos(Tempera tempera1, Tempera tempera2) {
        return !(tempera1.equals(tempera2));
    }

    public static Tempera add(Tempera tempera, double cantidad) {
        tempera.cantidad += cantidad;
        
        
        return tempera;
    }
}