package actividad3;



public class Paleta {
    private Tempera[] colores;
    private int cantidadMaximaColores;

    public Paleta(int cantidadMaximaColores) {
        this.cantidadMaximaColores = cantidadMaximaColores;
    }

    public String mostrar() {
        StringBuilder detalles = new StringBuilder();
        detalles.append("Colores actuales:\n");
        
        for (int i = 0; i < this.cantidadMaximaColores; i++){
            detalles.append(Tempera.mostrar(this.colores[i]));
        }
        
        detalles.append("Capacidad máxima: ").append(cantidadMaximaColores);

        
        return detalles.toString();
    }

    private int obtenerIndice() {
        int i = -1;   // Si no hay lugares disponibles
        
        for (int j = 0; j < this.cantidadMaximaColores; j++) {
            if (this.colores[j] == null) {
                i = j;  // Retorna el primer índice disponible
                
                break;
            }
        }
        
        
        return i;
    }

    private int obtenerIndice(Tempera tempera) {
        int i = -1;
        for (int j = 0; j < this.cantidadMaximaColores; j++) {
            if (colores[j] != null && Tempera.sonIguales(tempera, colores[j])) {
                i = j;
            }
        }
        
        
        return i;  // Si la tempera no está en la paleta
    }

    public static boolean sonIguales(Paleta paleta, Tempera tempera) {
        // Utiliza el método obtenerIndice para verificar si la Tempera está en la Paleta
        return paleta.obtenerIndice(tempera) != -1;
    }

    public static boolean sonDistintos(Paleta paleta, Tempera tempera) {
        return !(sonIguales(paleta, tempera));
    }

    public static Paleta add(Paleta paleta, Tempera tempera) {
        int indice = paleta.obtenerIndice(tempera);

        // Si la tempera ya está en la paleta, incrementa la cantidad
        if (indice != -1) {
            Tempera.add(paleta.colores[indice], 1);
        } 
        
        else {
            // Si no está, busca el primer índice disponible
            int indiceDisponible = paleta.obtenerIndice();
            
            if (indiceDisponible != -1) {
                paleta.colores[indiceDisponible] = tempera;  // Agrega la tempera en el primer lugar disponible
            }
        }
        
        
        return paleta;
    }

    public static Paleta add(Paleta paleta1, Paleta paleta2) {
        Paleta paletaCombinada = new Paleta(paleta1.cantidadMaximaColores + paleta2.cantidadMaximaColores);  // Crear nueva paleta con capacidad combinada

        // Agregar todas las temperas de paleta1 a la nueva paleta
        for (int i = 0; i < paleta1.cantidadMaximaColores; i++) {
            if (paleta1.colores[i] != null) {
                paletaCombinada = add(paletaCombinada, paleta1.colores[i]);  
                // Reusar el método add(Paleta, Tempera)
            }
        }

        // Agregar todas las temperas de paleta2 a la nueva paleta
        for (int i = 0; i < paleta2.cantidadMaximaColores; i++) {
            if (paleta2.colores[i] != null) {
                paletaCombinada = add(paletaCombinada, paleta2.colores[i]);  
                // Reusar el método add(Paleta, Tempera)
            }
        }

        
        return paletaCombinada;
    }

    public static Paleta remove(Paleta paleta, Tempera tempera) {
        int indice = paleta.obtenerIndice(tempera);
        
        if (indice != -1){
            Tempera.add(paleta.colores[indice], -1);
            
            if (paleta.colores[indice].getCantidad() <= 0){
                paleta.colores[indice] = null;
            }
        }
        
        
        return paleta;
    }
}