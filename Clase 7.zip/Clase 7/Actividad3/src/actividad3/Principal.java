package actividad3;



public class Principal {
    public static void main(String[] args) {
        // Método a resolver...
    }
}