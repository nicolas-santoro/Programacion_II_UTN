package actividad3;



public enum Color {
    ROJO,
    BLANCO,
    AZUL,
    VERDE,
    NEGRO;
}