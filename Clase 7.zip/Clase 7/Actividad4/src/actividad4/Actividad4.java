package actividad4;



import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Random;
import java.util.Stack;


public class Actividad4 {
    public static void main(String[] args) {
        // Crear las colecciones
        ArrayList<Integer> arrayList = new ArrayList<>();
        Stack<Integer> stack = new Stack<>();
        Queue<Integer> queue = new LinkedList<>();
        
        // Generar 20 números enteros aleatorios distintos de cero
        Random random = new Random();
        while (arrayList.size() < 20) {
            int num = random.nextInt(201) - 100; // Genera números entre -100 y 100
            if (num != 0 && !arrayList.contains(num)) { // Asegura que no se agregue 0 ni duplicados
                arrayList.add(num);
                stack.push(num);
                queue.offer(num);
            }
        }

        // 1. Mostrar la colección tal como fue cargada
        System.out.println("Coleccion cargada:");
        System.out.println("ArrayList: " + arrayList);
        System.out.println("Stack: " + stack);
        System.out.println("Queue: " + queue);

        // 2. Mostrar los positivos ordenados en forma decreciente
        ArrayList<Integer> positivos = new ArrayList<>();
        for (int num : arrayList) {
            if (num > 0) {
                positivos.add(num);
            }
        }
        Collections.sort(positivos, Collections.reverseOrder());
        System.out.println("\nPositivos ordenados en forma decreciente:");
        System.out.println(positivos);

        // 3. Mostrar los negativos ordenados en forma creciente
        ArrayList<Integer> negativos = new ArrayList<>();
        for (int num : arrayList) {
            if (num < 0) {
                negativos.add(num);
            }
        }
        Collections.sort(negativos);
        System.out.println("\nNegativos ordenados en forma creciente:");
        System.out.println(negativos);
    }   
}