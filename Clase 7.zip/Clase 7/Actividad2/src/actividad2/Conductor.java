package actividad2;



public class Conductor {
    private String nombre;
    private int[] kilometros;

    public Conductor(String nombre) {
        this.nombre = nombre;
        this.kilometros = new int[7]; // Inicializa el array de 7 días
    }

    public void agregarKilometros(int dia, int km) {
        if (dia >= 1 && dia <= 7) {
            this.kilometros[dia - 1] = km; // Guardar los km en el día correspondiente
        } 
        
        else {
            System.out.println("El dia debe estar entre 1 y 7...");
        }
    }

    public int totalKilometros() {
        int total = 0;
        
        for (int km : kilometros) {
            total += km;
        }
        
        
        return total;
    }

    public int kilometrosEnDia(int dia) {
        if (dia >= 1 && dia <= 7) {
            return this.kilometros[dia - 1];
        }
        
        
        return 0; // Si el día es inválido
    }
    
    public String getNombre() {
        return nombre;
    }
}