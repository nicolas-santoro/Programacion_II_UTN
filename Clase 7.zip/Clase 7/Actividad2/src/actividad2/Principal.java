package actividad2;



public class Principal {
    public static void main(String[] args) {
        EmpresaTransporte empresa = new EmpresaTransporte();

        // Crear y cargar conductores
        Conductor conductor1 = new Conductor("Juan");
        conductor1.agregarKilometros(1, 200);
        conductor1.agregarKilometros(2, 599);
        conductor1.agregarKilometros(3, 899);
        conductor1.agregarKilometros(4, 0);
        conductor1.agregarKilometros(5, 256);
        conductor1.agregarKilometros(6, 0);
        conductor1.agregarKilometros(7, 0);

        Conductor conductor2 = new Conductor("Pedro");
        conductor2.agregarKilometros(1, 300);
        conductor2.agregarKilometros(2, 150);
        conductor2.agregarKilometros(3, 500);
        conductor2.agregarKilometros(4, 0);
        conductor2.agregarKilometros(5, 600);
        conductor2.agregarKilometros(6, 200);
        conductor2.agregarKilometros(7, 0);

        Conductor conductor3 = new Conductor("Luis");
        conductor3.agregarKilometros(1, 100);
        conductor3.agregarKilometros(2, 200);
        conductor3.agregarKilometros(3, 800);
        conductor3.agregarKilometros(4, 0);
        conductor3.agregarKilometros(5, 700);
        conductor3.agregarKilometros(6, 0);
        conductor3.agregarKilometros(7, 0);

        // Agregar conductores a la empresa
        empresa.agregarConductor(conductor1);
        empresa.agregarConductor(conductor2);
        empresa.agregarConductor(conductor3);

        // Mostrar el conductor que hizo más km en la semana
        Conductor maxKmSemana = empresa.conductorConMasKmSemana();
        System.out.println("El conductor que hizo mas km en la semana es: " + maxKmSemana.getNombre());

        // Mostrar el conductor que hizo más km el día 3
        Conductor maxKmDia3 = empresa.conductorConMasKmDia(3);
        System.out.println("El conductor que hizo mas km el dia 3 es: " + maxKmDia3.getNombre());

        // Mostrar el conductor que hizo más km el día 5
        Conductor maxKmDia5 = empresa.conductorConMasKmDia(5);
        System.out.println("El conductor que hizo mas km el dia 5 es: " + maxKmDia5.getNombre());
    }
}