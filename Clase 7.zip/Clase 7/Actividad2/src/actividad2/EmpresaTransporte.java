package actividad2;



import java.util.ArrayList;
import java.util.List;


public class EmpresaTransporte {
    private List<Conductor> conductores;

    public EmpresaTransporte() {
        this.conductores = new ArrayList<>(); // Inicializar la lista conductores
    }

    public void agregarConductor(Conductor conductor) {
        conductores.add(conductor);
    }

    // Métodos para calcular el conductor con más kilómetros
    public Conductor conductorConMasKmSemana() {
        Conductor maxConductor = null;
        int maxKm = 0;
        
        for (Conductor conductor : conductores) {
            int totalKm = conductor.totalKilometros();
            
            if (totalKm > maxKm) {
                maxKm = totalKm;
                maxConductor = conductor;
            }
        }
        
        
        return maxConductor;
    }

    public Conductor conductorConMasKmDia(int dia) {
        Conductor maxConductor = null;
        int maxKm = 0;
        
        for (Conductor conductor : conductores) {
            int kmDia = conductor.kilometrosEnDia(dia);
            
            if (kmDia > maxKm) {
                maxKm = kmDia;
                maxConductor = conductor;
            }
        }
        
        
        return maxConductor;
    }
}