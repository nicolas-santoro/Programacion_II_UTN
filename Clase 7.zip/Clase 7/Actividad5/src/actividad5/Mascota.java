package actividad5;



import java.time.LocalDate;
import java.util.ArrayList;

public class Mascota {
    private String especie;
    private String nombre;
    private LocalDate fechaNacimiento;
    private ArrayList<String> historialVacunacion;

    // Constructor
    public Mascota(String especie, String nombre, LocalDate fechaNacimiento) {
        this.especie = especie;
        this.nombre = nombre;
        this.fechaNacimiento = fechaNacimiento;
        this.historialVacunacion = new ArrayList<>();
    }

    // Método para agregar una vacuna
    public void agregarVacuna(String vacuna) {
        this.historialVacunacion.add(vacuna);
    }

    // Método para mostrar datos de la mascota usando StringBuilder
    public String mostrarDatos() {
        StringBuilder datos = new StringBuilder();
        datos.append("Especie: ").append(this.especie).append("\n");
        datos.append("Nombre: ").append(this.nombre).append("\n");
        datos.append("Fecha de Nacimiento: ").append(this.fechaNacimiento).append("\n");
        datos.append("Vacunas: ");

        if (this.historialVacunacion.isEmpty()) {
            datos.append("No tiene vacunas registradas.");
        } 
        
        else {
            for (String vacuna : this.historialVacunacion) {
                datos.append(vacuna).append(", ");
            }
            datos.setLength(datos.length() - 2); // Eliminar la última coma y espacio
        }

        return datos.toString();
    }
}