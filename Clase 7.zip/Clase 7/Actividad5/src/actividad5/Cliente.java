package actividad5;



import java.util.ArrayList;


public class Cliente {
    private String domicilio;
    private String nombre;
    private String apellido;
    private int telefono;
    private ArrayList<Mascota> mascotas;

    public void agregarMascota(Mascota mascota) {
        this.mascotas.add(mascota);
    }

    public Cliente(String domicilio, String nombre, String apellido, int telefono) {
        this.domicilio = domicilio;
        this.nombre = nombre;
        this.apellido = apellido;
        this.telefono = telefono;
        this.mascotas = new ArrayList<>();
    }

    public String mostrarDatos() {
        StringBuilder datos = new StringBuilder();
        datos.append("Nombre completo: ").append(this.nombre).append(", ").append(this.apellido).append("\n");
        datos.append("Domicilio: ").append(this.domicilio).append("\n");
        datos.append("Telefono: ").append(this.telefono).append("\n");
        datos.append("Mascotas: \n");

        for (Mascota mascota : this.mascotas) {
            datos.append(mascota.mostrarDatos()).append("\n");
        }

        return datos.toString();
    }
}