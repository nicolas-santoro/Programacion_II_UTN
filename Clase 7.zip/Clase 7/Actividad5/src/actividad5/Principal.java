package actividad5;



import java.time.LocalDate;


public class Principal {
    public static void main(String[] args) {
        // Cliente con un perro sin vacunar
        Cliente cliente1 = new Cliente("Calle 123", "Juan", "Pérez", 123456789);
        Mascota perroSinVacunar = new Mascota("Perro", "Firulais", LocalDate.of(2019, 5, 20));
        cliente1.agregarMascota(perroSinVacunar);

        // Cliente con un gato con la vacuna "Triple Felina"
        Cliente cliente2 = new Cliente("Avenida Siempre Viva", "Lisa", "Simpson", 987654321);
        Mascota gatoConVacuna = new Mascota("Gato", "Whiskers", LocalDate.of(2018, 8, 15));
        gatoConVacuna.agregarVacuna("Triple Felina");
        cliente2.agregarMascota(gatoConVacuna);

        // Cliente con un gato sin vacunas y un perro con la vacuna contra la rabia
        Cliente cliente3 = new Cliente("Calle Falsa 456", "Homer", "Simpson", 654321987);
        Mascota gatoSinVacunas = new Mascota("Gato", "Garfield", LocalDate.of(2017, 12, 5));
        Mascota perroConRabia = new Mascota("Perro", "Scooby", LocalDate.of(2020, 10, 20));
        perroConRabia.agregarVacuna("Rabia");
        cliente3.agregarMascota(gatoSinVacunas);
        cliente3.agregarMascota(perroConRabia);

        // Mostrar los datos de los clientes y sus mascotas
        System.out.println(cliente1.mostrarDatos());
        System.out.println(cliente2.mostrarDatos());
        System.out.println(cliente3.mostrarDatos());
    }
}