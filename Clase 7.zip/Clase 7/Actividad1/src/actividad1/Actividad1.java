package actividad1;



import java.util.Arrays;
import java.util.Random;


public class Actividad1 {
    public static void main(String[] args) {
        int[] numeros = new int[20];
        Random random = new Random();
        
        // Generar 20 números enteros aleatorios distintos de cero
        for (int i = 0; i < numeros.length; i++) {
            numeros[i] = random.nextInt(201) - 100; // Genera entre -100 y 100
            if (numeros[i] == 0) {
                i--; // Si es 0, repetir el número
            }
        }

        // Mostrar el vector tal como fue ingresado
        System.out.println("Vector original: ");
        System.out.println(Arrays.toString(numeros));

        // Mostrar los positivos en orden decreciente
        int[] positivos = Arrays.stream(numeros)
                                .filter(num -> num > 0)
                                .toArray();
        Arrays.sort(positivos); // Ordenar en orden ascendente
        System.out.println("\nPositivos en orden decreciente: ");
        for (int i = positivos.length - 1; i >= 0; i--) {
            System.out.print(positivos[i] + " ");
        }
        System.out.println();

        // Mostrar los negativos en orden creciente
        int[] negativos = Arrays.stream(numeros)
                                .filter(num -> num < 0)
                                .toArray();
        Arrays.sort(negativos); // Ordenar en orden ascendente
        System.out.println("\nNegativos en orden creciente: ");
        for (int num : negativos) {
            System.out.print(num + " ");
        }
        System.out.println();
    }
}