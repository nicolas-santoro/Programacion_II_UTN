package actividad6;



public class Jugador {
    private int dni;
    private String nombre;
    private int partidosJugados;
    private float promedioGoles = 0;
    private int totalGoles;

    private Jugador() {
       this.partidosJugados = 0;
       this.promedioGoles = 0;
       this.totalGoles = 0;
    }

    public Jugador(int dni, String nombre) {
        this.dni = dni;
        this.nombre = nombre;
        this.partidosJugados = 0;
        this.promedioGoles = 0;
        this.totalGoles = 0;
    }

    public Jugador(int dni, String nombre, int partidosJugados, int totalGoles) {
        this.dni = dni;
        this.nombre = nombre;
        this.partidosJugados = partidosJugados;
        this.totalGoles = totalGoles;
        this.promedioGoles = 0;
    }

    public float getPromedioGoles() {
    if (this.partidosJugados > 0) {
        this.promedioGoles = (float) this.totalGoles / this.partidosJugados;
    } 
    
    else {
        this.promedioGoles = 0; // Asegura que el promedio sea 0 si no hay partidos jugados
    }
    
    
    return this.promedioGoles; // Retorna el promedio (ya sea calculado o 0)
}

    public String mostrarDatos() {
        StringBuilder datos = new StringBuilder();
        
        datos.append("DNI: ").append(this.dni).append("\n");
        datos.append("Nombre: ").append(this.nombre).append("\n");
        datos.append("Partidos jugados: ").append(this.partidosJugados).append("\n");
        datos.append("Goles: ").append(this.totalGoles).append("\n");
        datos.append("Promedio de goles: ").append(this.promedioGoles);
        
        return datos.toString();
    }

    public static boolean sonIguales(Jugador jugador1, Jugador jugador2) {
        return jugador1.dni == jugador2.dni;
    }

    public static boolean sonDistintos(Jugador jugador1, Jugador jugador2) {
        return !(sonIguales(jugador1, jugador2));
    }
}