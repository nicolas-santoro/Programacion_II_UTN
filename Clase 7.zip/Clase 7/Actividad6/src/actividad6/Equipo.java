package actividad6;



import java.util.ArrayList;


public class Equipo {
    private int cantidadJugadores;
    private String nombre;
    private ArrayList<Jugador> jugadores;

    private Equipo() {
        this.jugadores = new ArrayList<>();
    }

    public Equipo(int cantidadJugadores, String nombre) {
        this.cantidadJugadores = cantidadJugadores;
        this.nombre = nombre;
        
        this.jugadores = new ArrayList<>();
    }

    public static Equipo add(Equipo equipo, Jugador jugador) {
        // Verificar si el jugador ya está en el equipo
        for (Jugador i : equipo.jugadores) {
            if (Jugador.sonIguales(i, jugador)) {
                System.out.println("El jugador ya existe en el equipo.");
                
                
                return equipo; // Retorna el equipo sin cambios
            }
        }

        // Verificar si se puede agregar más jugadores
        if (equipo.jugadores.size() < equipo.cantidadJugadores) {
            equipo.jugadores.add(jugador);
            
            System.out.println("Jugador agregado al equipo.");
        } 
        
        else {
            System.out.println("No se puede agregar mas jugadores, se alcanzo el límite.");
        }

        
        return equipo; // Retorna la instancia del equipo (puede ser la misma o una nueva)
    }
    
    public void mostrarJugadores() {
        System.out.println("Jugadores en el equipo:");
        
        for (Jugador jugador : jugadores) {
            String datos = jugador.mostrarDatos(); // Llama al método mostrarDatos de cada jugador
            
            System.out.println(datos);
        }
    }
}