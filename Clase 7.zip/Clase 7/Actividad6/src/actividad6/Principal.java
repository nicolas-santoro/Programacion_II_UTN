package actividad6;



public class Principal {
    public static void main(String[] args) {
        // Crear un equipo con un límite de 3 jugadores
        Equipo equipo = new Equipo(3, "Equipo A");
        
        // Crear algunos jugadores
        Jugador jugador1 = new Jugador(12345678, "Juan", 20, 12);
        Jugador jugador2 = new Jugador(87654321, "Pedro", 40, 20);
        Jugador jugador3 = new Jugador(13579246, "Luis", 10, 2);
        Jugador jugador4 = new Jugador(12345678, "Carlos", 50, 40); // Mismo DNI que jugador1

        // Intentar agregar jugadores al equipo
        Equipo.add(equipo, jugador1); // Debería agregar
        Equipo.add(equipo, jugador2); // Debería agregar
        Equipo.add(equipo, jugador3); // Debería agregar
        Equipo.add(equipo, jugador4); // No debería agregar, ya que el DNI es el mismo que jugador1

        // Mostrar los jugadores del equipo
        equipo.mostrarJugadores();
    }
}